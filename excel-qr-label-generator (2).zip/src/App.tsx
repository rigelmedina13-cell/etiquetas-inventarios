import { useEffect, useMemo, useRef, useState } from "react";
import {
  Printer,
  FileSpreadsheet,
  Ellipsis,
  Search,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Plus,
  Minus,
  Trash2,
  Laptop,
  Pencil,
  X,
  Download,
  RotateCcw,
  Check,
  Loader2,
} from "lucide-react";
import { DEFAULT_LABEL_CONFIG, DEFAULT_PRINTERS, INITIAL_SAMPLE_MATERIALS, LABEL_SIZE_PRESETS } from "./data/defaultMaterials";
import { LabelConfig, MaterialItem, NetworkPrinter, QueueEntry } from "./types/label";
import { LabelRenderer, getAvailableTopMm, getDesiredQrMm } from "./components/LabelRenderer";
import { PrintSheetArea } from "./components/PrintSheetArea";
import { getAvailableColumns, getFieldValue } from "./utils/labelColumns";
import { columnKeyFromHeader } from "./utils/labelColumns";
import { downloadCatalogBackup, downloadExcelTemplate, mapRowsToMaterials, parseExcelFile, ParsedWorkbookData } from "./utils/excelHelper";
import { buildZplBatch, buildZplForMaterial, downloadTextFile, sendZplToPrinter } from "./utils/zpl";
import { loadCatalog, mergeMaterials, saveCatalog } from "./utils/catalogStorage";
import { ExcelImportDialog } from "./components/ExcelImportDialog";
import { LabelDesignEditor } from "./components/LabelDesignEditor";

const PX_PER_MM = 3.7795275591;
const PAGE_SIZE = 10;

function Switch({ checked, onChange, id }: { checked: boolean; onChange: (v: boolean) => void; id: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      id={id}
      onClick={() => onChange(!checked)}
      className={`inline-flex h-[1.15rem] w-8 shrink-0 items-center rounded-full border border-transparent shadow-xs transition-all outline-none focus-visible:ring-[3px] focus-visible:ring-[var(--ring)]/50 cursor-pointer ${
        checked ? "bg-[var(--primary)] justify-end" : "bg-[var(--input)] justify-start"
      }`}
    >
      <span className="pointer-events-none block size-4 rounded-full bg-white shadow transition-transform" />
    </button>
  );
}

function FieldSelect({
  id,
  value,
  onChange,
  options,
  style,
}: {
  id: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  style?: React.CSSProperties;
}) {
  return (
    <div className="relative">
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={style}
        className="h-11 w-full appearance-none rounded-md border border-[var(--input)] bg-transparent px-3 pr-9 text-base shadow-xs outline-none focus:border-[var(--ring)] focus:ring-[3px] focus:ring-[var(--ring)]/50 cursor-pointer"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 opacity-50" />
    </div>
  );
}

export default function App() {
  const [materials, setMaterials] = useState<MaterialItem[]>(INITIAL_SAMPLE_MATERIALS);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [queue, setQueue] = useState<QueueEntry[]>([]);
  const [config, setConfig] = useState<LabelConfig>(() => {
    try {
      const saved = localStorage.getItem("inv_labels_config_v1");
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...DEFAULT_LABEL_CONFIG, ...parsed, qrSize: (parsed as Partial<LabelConfig>).qrSize || "md" };
      }
    } catch {}
    return DEFAULT_LABEL_CONFIG;
  });
  const [printers, setPrinters] = useState<NetworkPrinter[]>(() => {
    try {
      const saved = localStorage.getItem("inv_labels_printers_v1");
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_PRINTERS;
  });
  const [selectedPrinterId, setSelectedPrinterId] = useState<string>(() => {
    return localStorage.getItem("inv_labels_printer_sel_v1") || DEFAULT_PRINTERS[0].id;
  });
  const [editingPrinter, setEditingPrinter] = useState<Partial<NetworkPrinter> | null>(null);
  const [isAddingPrinter, setIsAddingPrinter] = useState(false);
  const [printLabels, setPrintLabels] = useState<MaterialItem[]>([]);
  const [toast, setToast] = useState<{ title: string; desc?: string; kind: "ok" | "err" } | null>(null);
  const [sending, setSending] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [importedFileNames, setImportedFileNames] = useState<string[]>([]);
  const [catalogColumns, setCatalogColumns] = useState<string[]>(["codigo", "descripcion"]);
  const [pendingExcel, setPendingExcel] = useState<ParsedWorkbookData | null>(null);
  const [savingColumns, setSavingColumns] = useState(false);
  const [catalogReady, setCatalogReady] = useState(false);
  const [importing, setImporting] = useState(false);

  const fileRef = useRef<HTMLInputElement | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    loadCatalog()
      .then((saved) => {
        if (cancelled || !saved) return;
        if (Array.isArray(saved.materials)) {
          // Restore original examples even for catalogs saved by the old replace-on-import behavior.
          const restored = mergeMaterials(INITIAL_SAMPLE_MATERIALS, saved.materials);
          setMaterials(restored);
          setPreviewId(null);
        }
        const names = Array.isArray(saved.fileNames) ? saved.fileNames : [];
        setImportedFileNames(names);
        setFileName(names.at(-1) || null);
        if (Array.isArray(saved.visibleColumns) && saved.visibleColumns.length > 0) {
          setCatalogColumns(saved.visibleColumns);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setToast({
            title: "No se pudo abrir el catálogo guardado",
            desc: "Comprueba que el navegador permita almacenamiento local.",
            kind: "err",
          });
        }
      })
      .finally(() => {
        if (!cancelled) setCatalogReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("inv_labels_config_v1", JSON.stringify(config));
    } catch {}
  }, [config]);
  useEffect(() => {
    try {
      localStorage.setItem("inv_labels_printers_v1", JSON.stringify(printers));
    } catch {}
  }, [printers]);
  useEffect(() => {
    try {
      localStorage.setItem("inv_labels_printer_sel_v1", selectedPrinterId);
    } catch {}
  }, [selectedPrinterId]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4200);
    return () => clearTimeout(t);
  }, [toast]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const columns = useMemo(() => getAvailableColumns(materials), [materials]);
  const visibleCatalogColumns = useMemo(() => {
    const result = columns.filter((col) => catalogColumns.includes(col.key));
    return result.length > 0 ? result : columns.slice(0, 2);
  }, [columns, catalogColumns]);
  const materialById = useMemo(() => new Map(materials.map((item) => [item.id, item])), [materials]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return materials;
    return materials.filter((m) => {
      if (m.codigo.toLowerCase().includes(q)) return true;
      if (m.descripcion.toLowerCase().includes(q)) return true;
      if ((m.ubicacion || "").toLowerCase().includes(q)) return true;
      if ((m.lote || "").toLowerCase().includes(q)) return true;
      if ((m.categoria || "").toLowerCase().includes(q)) return true;
      return Object.values(m.extraFields || {}).some((v) => v.toLowerCase().includes(q));
    });
  }, [materials, search]);

  useEffect(() => {
    setPage(0);
  }, [search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);
  const pageItems = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);

  const previewMaterial = useMemo(
    () => materials.find((m) => m.id === previewId) || null,
    [materials, previewId]
  );

  const queueDetailed = useMemo(() => {
    return queue
      .map((q) => ({ entry: q, material: materialById.get(q.materialId) || null }))
      .filter((x): x is { entry: QueueEntry; material: MaterialItem } => x.material !== null);
  }, [queue, materialById]);

  const totalQueueLabels = queueDetailed.reduce((acc, q) => acc + q.entry.qty, 0);

  const selectedPrinter = printers.find((p) => p.id === selectedPrinterId) || printers[0] || null;

  const updateConfig = (patch: Partial<LabelConfig>) => setConfig((p) => ({ ...p, ...patch }));

  const toggleBodyField = (key: string) => {
    setConfig((p) => {
      const has = p.bodyFields.includes(key);
      return { ...p, bodyFields: has ? p.bodyFields.filter((k) => k !== key) : [...p.bodyFields, key] };
    });
  };

  const addToQueue = (id: string) => {
    setPreviewId(id);
    setQueue((prev) => {
      const found = prev.find((q) => q.materialId === id);
      if (found) return prev.map((q) => (q.materialId === id ? { ...q, qty: Math.min(999, q.qty + 1) } : q));
      return [...prev, { materialId: id, qty: 1 }];
    });
  };

  const setQty = (id: string, qty: number) => {
    const v = Math.max(1, Math.min(999, qty || 1));
    setQueue((prev) => prev.map((q) => (q.materialId === id ? { ...q, qty: v } : q)));
  };

  const removeFromQueue = (id: string) => setQueue((prev) => prev.filter((q) => q.materialId !== id));

  const handleFile = async (file: File) => {
    if (!catalogReady || importing) return;
    setImporting(true);
    try {
      const parsed = await parseExcelFile(file);
      if (parsed.headers.length === 0 && parsed.sheetNames.length <= 1) {
        setToast({ title: "Archivo vacío", desc: "No se encontraron columnas con materiales en el archivo.", kind: "err" });
        return;
      }
      setPendingExcel(parsed);
    } catch (error) {
      setToast({ title: "No se pudo leer el archivo", desc: error instanceof Error ? error.message : "Usa un Excel válido.", kind: "err" });
    } finally {
      setImporting(false);
    }
  };

  const confirmExcelImport = async (parsed: ParsedWorkbookData, selectedHeaders: string[]) => {
    if (!catalogReady || importing) return;
    setImporting(true);
    try {
      const mapped = mapRowsToMaterials(parsed.rawRows, parsed.mapping, parsed.headers);
      if (mapped.length === 0) {
        setToast({ title: "Sin materiales válidos", desc: "Revisa las columnas de código y descripción.", kind: "err" });
        return;
      }
      // Always preserve the existing catalog, including the original example materials.
      const next = mergeMaterials(materials, mapped);
      const names = Array.from(new Set([...importedFileNames, parsed.fileName]));
      const visibleColumns = Array.from(new Set(selectedHeaders.map((h) => columnKeyFromHeader(h, parsed.mapping))));
      await saveCatalog({ materials: next, fileNames: names, visibleColumns, updatedAt: new Date().toISOString() });
      setMaterials(next);
      setCatalogColumns(visibleColumns);
      setQueue((previous) => previous.filter((item) => next.some((material) => material.id === item.materialId)));
      setPreviewId(next.find((item) => item.codigo === mapped[0].codigo)?.id || null);
      setFileName(parsed.fileName);
      setImportedFileNames(names);
      setPendingExcel(null);
      setSearch("");
      setPage(0);
      setToast({ title: "Catálogo guardado en este navegador", desc: `${mapped.length} filas importadas · ${next.length} materiales en total`, kind: "ok" });
    } catch (error) {
      setToast({ title: "No se pudo guardar el catálogo", desc: error instanceof Error ? error.message : "Permite el almacenamiento local.", kind: "err" });
    } finally {
      setImporting(false);
    }
  };

  const toggleCatalogColumn = async (key: string) => {
    if (savingColumns || !catalogReady) return;
    const next = catalogColumns.includes(key) ? catalogColumns.filter((c) => c !== key) : [...catalogColumns, key];
    if (next.length === 0) {
      setToast({ title: "Selecciona al menos una columna", kind: "err" });
      return;
    }
    setSavingColumns(true);
    try {
      await saveCatalog({ materials, fileNames: importedFileNames, visibleColumns: next, updatedAt: new Date().toISOString() });
      setCatalogColumns(next);
    } catch {
      setToast({ title: "No se pudo guardar la selección de columnas", kind: "err" });
    } finally {
      setSavingColumns(false);
    }
  };

  const restoreExamples = async () => {
    if (!catalogReady || importing) return;
    try {
      // Existing imported values win if an example has the same code.
      const next = mergeMaterials(INITIAL_SAMPLE_MATERIALS, materials);
      await saveCatalog({ materials: next, fileNames: importedFileNames, visibleColumns: catalogColumns, updatedAt: new Date().toISOString() });
      setMaterials(next);
      setPreviewId(null);
      setSearch("");
      setPage(0);
      setToast({ title: "Ejemplos restaurados", desc: "Tus materiales importados siguen en el catálogo.", kind: "ok" });
    } catch {
      setToast({ title: "No se pudo guardar el catálogo", kind: "err" });
    }
    setMenuOpen(false);
  };

  const handlePrint = async () => {
    if (queueDetailed.length === 0) return;
    if (config.outputMode === "browser") {
      const expanded: MaterialItem[] = [];
      for (const q of queueDetailed) {
        for (let i = 0; i < q.entry.qty; i++) expanded.push(q.material);
      }
      setPrintLabels(expanded);
      setTimeout(() => window.print(), 80);
    } else {
      if (!selectedPrinter) {
        setToast({ title: "Sin impresora", desc: "Agrega una impresora de red primero.", kind: "err" });
        return;
      }
      setSending(true);
      try {
        const qtyMap = new Map(queueDetailed.map((q) => [q.material.id, q.entry.qty] as [string, number]));
        const mats = queueDetailed.map((q) => q.material);
        const zpl = buildZplBatch(mats, qtyMap, config, selectedPrinter);
        await sendZplToPrinter(zpl, selectedPrinter);
        setToast({
          title: "Lote enviado a la impresora",
          desc: `${totalQueueLabels} etiqueta(s) → ${selectedPrinter.ip}:${selectedPrinter.port}`,
          kind: "ok",
        });
      } catch {
        // Fallback: descargar ZPL
        const qtyMap = new Map(queueDetailed.map((q) => [q.material.id, q.entry.qty] as [string, number]));
        const mats = queueDetailed.map((q) => q.material);
        const zpl = buildZplBatch(mats, qtyMap, config, selectedPrinter);
        downloadTextFile(`etiquetas_${config.widthMm}x${config.heightMm}mm.zpl`, zpl);
        setToast({
          title: "Archivo ZPL descargado",
          desc: `Para ${selectedPrinter.ip}:${selectedPrinter.port}. Envíalo con un puente local o una utilidad Zebra.`,
          kind: "ok",
        });
      } finally {
        setSending(false);
      }
    }
  };

  const handleTestLabel = async () => {
    if (!selectedPrinter) return;
    const sample = previewMaterial || materials[0];
    if (!sample) return;
    setSending(true);
    try {
      const zpl = buildZplForMaterial(sample, config, selectedPrinter);
      await sendZplToPrinter(zpl, selectedPrinter);
      setToast({ title: "Etiqueta de prueba enviada", desc: `${selectedPrinter.ip}:${selectedPrinter.port}`, kind: "ok" });
    } catch {
      const zpl = buildZplForMaterial(sample, config, selectedPrinter);
      downloadTextFile(`prueba_${sample.codigo}.zpl`, zpl);
      setToast({ title: "Etiqueta de prueba ZPL descargada", desc: `Impresora: ${selectedPrinter.ip}:${selectedPrinter.port}`, kind: "ok" });
    } finally {
      setSending(false);
    }
  };

  const labelWpx = config.widthMm * PX_PER_MM;
  const labelHpx = config.heightMm * PX_PER_MM;
  const previewScale = Math.min(1, 330 / labelWpx, 210 / labelHpx);

  const qrPreviewMm = useMemo(() => {
    if (!config.includeQr) return 0;
    const hasBody = config.bodyFields.length > 0;
    const hasFooter = Boolean((config.footerText || "").trim());
    const hasTop = config.titleField !== "__none__" || config.includeQr;
    const showH = config.showHeaderDivider && config.dividerStyle !== "none" && hasTop && (hasBody || hasFooter);
    const showF = config.showFooterDivider && config.dividerStyle !== "none" && hasFooter && (hasTop || hasBody);
    const avail = getAvailableTopMm(config, hasBody, hasFooter, showH, showF);
    return getDesiredQrMm(config, avail);
  }, [config]);

  return (
    <>
      <div className="min-h-screen pb-12 print:hidden" style={{ background: "var(--background)", color: "var(--foreground)" }}>
        {/* Header oscuro */}
        <header style={{ background: "var(--header)", color: "var(--header-foreground)" }}>
          <div className="mx-auto flex max-w-[84rem] flex-wrap items-center gap-4 px-4 py-4 sm:px-6">
            <div className="flex flex-1 items-center gap-4">
              <div
                className="grid size-12 place-items-center rounded-lg"
                style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
              >
                <Printer className="size-6" />
              </div>
              <div>
                <p className="font-display text-2xl leading-none font-bold tracking-wide">ETIQUETAS DE INVENTARIOS</p>
                <p className="mt-1 text-sm opacity-70">Etiquetas de material con QR</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={!catalogReady || importing}
                className="inline-flex h-11 items-center gap-2 rounded-md px-5 text-base font-medium transition-all hover:brightness-95 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
              >
                {importing ? <Loader2 className="size-5 animate-spin" /> : <FileSpreadsheet className="size-5" />}
                {importing ? "Guardando..." : "Importar Excel"}
              </button>
              <div className="relative" ref={menuRef}>
                <button
                  type="button"
                  aria-label="Más opciones"
                  onClick={() => setMenuOpen((v) => !v)}
                  className="grid size-10 place-items-center rounded-md text-sm transition-colors hover:bg-white/10 cursor-pointer"
                >
                  <Ellipsis className="size-5" />
                </button>
                {menuOpen && (
                  <div
                    className="absolute right-0 z-40 mt-2 w-64 overflow-hidden rounded-lg border bg-white shadow-xl"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        downloadExcelTemplate();
                        setMenuOpen(false);
                      }}
                      className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-neutral-800 hover:bg-neutral-100 cursor-pointer"
                    >
                      <Download className="size-4" /> Descargar plantilla Excel
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        downloadCatalogBackup(materials);
                        setMenuOpen(false);
                      }}
                      disabled={materials.length === 0}
                      className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-neutral-800 hover:bg-neutral-100 cursor-pointer disabled:opacity-50"
                    >
                      <Download className="size-4" /> Descargar respaldo del catálogo
                    </button>
                    <button
                      type="button"
                      onClick={restoreExamples}
                      disabled={!catalogReady || importing}
                      className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-neutral-800 hover:bg-neutral-100 cursor-pointer"
                    >
                      <RotateCcw className="size-4" /> Restaurar ejemplos
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setQueue([]);
                        setMenuOpen(false);
                      }}
                      className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-neutral-800 hover:bg-neutral-100 cursor-pointer"
                    >
                      <X className="size-4" /> Vaciar cola
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setConfig(DEFAULT_LABEL_CONFIG);
                        setMenuOpen(false);
                        setToast({ title: "Diseño restablecido", kind: "ok" });
                      }}
                      className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-neutral-800 hover:bg-neutral-100 cursor-pointer"
                    >
                      <Check className="size-4" /> Restablecer diseño clásico
                    </button>
                  </div>
                )}
              </div>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls,.csv,.ods"
              disabled={!catalogReady || importing}
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
                e.target.value = "";
              }}
            />
          </div>
        </header>

        <main className="mx-auto grid max-w-[84rem] gap-6 px-4 pt-8 sm:px-6 lg:grid-cols-[minmax(0,1fr)_26rem]">
          {/* Catálogo */}
          <div className="min-w-0">
            <h1 className="font-display text-4xl font-bold tracking-tight">Catálogo de materiales</h1>
            <p className="mt-1 mb-6 text-lg" style={{ color: "var(--muted-foreground)" }}>
              {fileName ? `${fileName} · ` : ""}
              {filtered.length} resultado{filtered.length === 1 ? "" : "s"} · toca un material para agregarlo a la cola
            </p>

            <section className="rounded-xl border shadow-xs" style={{ background: "var(--card)", borderColor: "var(--border)" }}>
              <div className="flex flex-col gap-3 border-b p-4 sm:flex-row" style={{ borderColor: "var(--border)" }}>
                <label className="relative flex-1">
                  <span className="sr-only">Buscar materiales</span>
                  <Search className="pointer-events-none absolute top-1/2 left-3 size-5 -translate-y-1/2" style={{ color: "var(--muted-foreground)" }} />
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && filtered.length === 1) addToQueue(filtered[0].id);
                    }}
                    placeholder="Buscar por número o descripción (Enter agrega si hay un solo resultado)"
                    className="h-11 w-full rounded-md border bg-transparent pr-3 pl-10 text-base outline-none placeholder:text-[var(--muted-foreground)] focus:border-[var(--ring)] focus:ring-[3px] focus:ring-[var(--ring)]/50"
                    style={{ borderColor: "var(--input)" }}
                  />
                </label>
              </div>

              <details className="border-b px-4 py-2.5 text-sm" style={{ borderColor: "var(--border)" }}>
                <summary className="cursor-pointer font-medium" style={{ color: "var(--muted-foreground)" }}>
                  Columnas visibles en el catálogo ({visibleCatalogColumns.length})
                </summary>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 pt-3 sm:grid-cols-3">
                  {columns.map((col) => (
                    <label key={col.key} className="flex min-w-0 cursor-pointer items-center gap-2 py-1">
                      <input type="checkbox" checked={catalogColumns.includes(col.key)} disabled={savingColumns} onChange={() => toggleCatalogColumn(col.key)} className="size-4 shrink-0 accent-[var(--primary)]" />
                      <span className="truncate" title={col.label}>{col.label}</span>
                    </label>
                  ))}
                </div>
              </details>

              <div className="max-h-[34rem] overflow-auto nice-scroll">
                {pageItems.length === 0 ? (
                  <p className="px-6 py-12 text-center text-sm" style={{ color: "var(--muted-foreground)" }}>
                    Sin resultados. Importa un Excel o ajusta la búsqueda.
                  </p>
                ) : (
                  <ul style={{ minWidth: `${visibleCatalogColumns.length * 148 + 125}px` }}>
                    <li className="flex items-center gap-4 border-b bg-neutral-50 px-6 py-2 text-xs font-semibold" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
                      <span className="size-8 shrink-0" />
                      {visibleCatalogColumns.map((col) => <span key={col.key} className="min-w-0 flex-1 truncate" title={col.label}>{col.label}</span>)}
                      <span className="w-9 shrink-0" />
                    </li>
                    {pageItems.map((m) => {
                      const inQueue = queue.find((q) => q.materialId === m.id);
                      const isPreview = previewId === m.id;
                      return (
                        <li key={m.id} className="border-b last:border-b-0" style={{ borderColor: "var(--border)" }}>
                          <button
                            type="button"
                            onClick={() => addToQueue(m.id)}
                            title="Agregar a la cola"
                            className={`flex w-full items-center gap-4 px-6 py-4 text-left transition-colors cursor-pointer ${
                              isPreview ? "bg-[var(--primary)]/8" : "hover:bg-[var(--accent)]/60"
                            }`}
                          >
                            <span
                              className="grid size-8 shrink-0 place-items-center rounded-md border"
                              style={{ borderColor: "var(--input)", color: "var(--muted-foreground)" }}
                            >
                              <Plus className="size-4" />
                            </span>
                            {visibleCatalogColumns.map((col) => (
                              <span key={col.key} className="min-w-0 flex-1 truncate text-sm" title={getFieldValue(m, col.key)} style={col.key === "codigo" ? { fontFamily: "var(--font-code)", fontWeight: 600 } : undefined}>
                                {getFieldValue(m, col.key) || "—"}
                              </span>
                            ))}
                            {inQueue && (
                              <span
                                className="shrink-0 rounded-full px-2.5 py-1 font-mono text-xs font-semibold"
                                style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
                              >
                                ×{inQueue.qty}
                              </span>
                            )}
                            {!inQueue && <span className="w-9 shrink-0" />}
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>

              <div
                className="flex items-center justify-between gap-3 border-t px-4 py-3"
                style={{ borderColor: "var(--border)" }}
              >
                <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                  {filtered.length === 0
                    ? "0 resultados"
                    : `Mostrando ${safePage * PAGE_SIZE + 1}–${Math.min(filtered.length, safePage * PAGE_SIZE + PAGE_SIZE)} de ${filtered.length}`}
                </p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    aria-label="Página anterior"
                    disabled={safePage === 0}
                    onClick={() => setPage((p) => Math.max(0, p - 1))}
                    className="grid size-9 place-items-center rounded-md border shadow-xs transition-all hover:bg-[var(--accent)] disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
                    style={{ borderColor: "var(--input)" }}
                  >
                    <ChevronLeft className="size-4" />
                  </button>
                  <span className="font-mono text-sm" style={{ fontFamily: "var(--font-code)" }}>
                    {safePage + 1}/{totalPages}
                  </span>
                  <button
                    type="button"
                    aria-label="Página siguiente"
                    disabled={safePage >= totalPages - 1}
                    onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                    className="grid size-9 place-items-center rounded-md border shadow-xs transition-all hover:bg-[var(--accent)] disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
                    style={{ borderColor: "var(--input)" }}
                  >
                    <ChevronRight className="size-4" />
                  </button>
                </div>
              </div>
            </section>
          </div>

          {/* Panel lateral */}
          <aside className="grid content-start gap-6 lg:sticky lg:top-6 lg:pt-[5.75rem]">
            {/* Vista previa + contenido */}
            <section className="overflow-hidden rounded-xl border shadow-xs" style={{ background: "var(--card)", borderColor: "var(--border)" }}>
              <div className="px-6 pt-5 pb-6" style={{ background: "color-mix(in oklab, var(--muted) 60%, transparent)" }}>
                <div className="mb-4 flex items-center justify-between gap-3">
                  <p className="text-sm font-medium tracking-wider uppercase" style={{ color: "var(--muted-foreground)" }}>
                    Vista previa · {config.widthMm} × {config.heightMm} mm
                  </p>
                </div>
                <div className="mx-auto flex items-center justify-center overflow-hidden" style={{ height: labelHpx }}>
                  {previewMaterial ? (
                    <div
                      className="bg-white shadow-md"
                      style={{ zoom: previewScale } as React.CSSProperties}
                      title="Vista previa en tiempo real"
                    >
                      <LabelRenderer material={previewMaterial} config={config} />
                    </div>
                  ) : (
                    <div
                      className="grid place-items-center rounded-sm border-2 border-dashed p-6 text-center text-sm"
                      style={{ width: labelWpx, height: labelHpx, borderColor: "var(--border)", background: "color-mix(in oklab, var(--background) 60%, transparent)", color: "var(--muted-foreground)" }}
                    >
                      Toca un material del catálogo para ver su etiqueta
                    </div>
                  )}
                </div>
              </div>

              <div className="grid gap-5 border-t p-6" style={{ borderColor: "var(--border)" }}>
                <div className="grid gap-4">
                  <div>
                    <p className="font-display text-lg font-bold">Contenido de la etiqueta</p>
                    <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                      Elige qué columnas del Excel se muestran. Importa un Excel con más columnas para ver más opciones.
                    </p>
                  </div>

                  <div className="grid gap-2">
                    <label htmlFor="title-field" className="text-base font-medium">
                      Texto grande (arriba)
                    </label>
                    <FieldSelect
                      id="title-field"
                      value={config.titleField}
                      onChange={(v) => updateConfig({ titleField: v })}
                      options={[
                        { value: "__none__", label: "Ninguno (solo QR)" },
                        ...columns.map((c) => ({ value: c.key, label: c.label })),
                      ]}
                    />
                  </div>

                  <fieldset className="grid gap-2">
                    <legend className="mb-2 text-base font-medium">Texto del cuerpo</legend>
                    <ul className="divide-y rounded-md border" style={{ borderColor: "var(--input)" }}>
                      {columns.map((c) => {
                        const checked = config.bodyFields.includes(c.key);
                        const sampleMaterial = previewMaterial || materials[0];
                        const sample = sampleMaterial ? getFieldValue(sampleMaterial, c.key) : "";
                        return (
                          <li key={c.key} className="flex items-center gap-3 px-3 py-2">
                            <input
                              type="checkbox"
                              id={`body-${c.key}`}
                              checked={checked}
                              onChange={() => toggleBodyField(c.key)}
                              className="size-4 shrink-0 cursor-pointer rounded accent-[var(--primary)]"
                            />
                            <label htmlFor={`body-${c.key}`} className="min-w-0 flex-1 cursor-pointer">
                              <span className="block text-sm font-medium">{c.label}</span>
                              {sample && (
                                <span className="block truncate text-xs" style={{ color: "var(--muted-foreground)" }} title={sample}>
                                  {sample}
                                </span>
                              )}
                            </label>
                          </li>
                        );
                      })}
                    </ul>
                  </fieldset>

                  <div className="flex items-center justify-between gap-4">
                    <label htmlFor="names" className="text-base font-medium">
                      Mostrar nombre de la columna
                    </label>
                    <Switch id="names" checked={config.showFieldNames} onChange={(v) => updateConfig({ showFieldNames: v })} />
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <label htmlFor="qr" className="text-base font-medium">
                      Incluir código QR
                    </label>
                    <Switch id="qr" checked={config.includeQr} onChange={(v) => updateConfig({ includeQr: v })} />
                  </div>

                  {config.includeQr && (
                    <div className="grid gap-2">
                      <label htmlFor="qr-field" className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                        El QR contiene
                      </label>
                      <FieldSelect
                        id="qr-field"
                        value={config.qrField}
                        onChange={(v) => updateConfig({ qrField: v })}
                        options={[
                          { value: "__title__", label: "Mismo que el título" },
                          ...columns.map((c) => ({ value: c.key, label: c.label })),
                        ]}
                      />
                    </div>
                  )}
                </div>

                <div className="h-px w-full" style={{ background: "var(--border)" }} />

                <div className="grid gap-4">
                  <div>
                    <p className="font-display text-lg font-bold">Formato de letra</p>
                    <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                      Tipo, tamaño y estilo del texto de la etiqueta.
                    </p>
                  </div>

                  <div className="grid gap-2">
                    <label htmlFor="font-family" className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                      Tipo de letra
                    </label>
                    <FieldSelect
                      id="font-family"
                      value={config.fontFamily}
                      onChange={(v) => updateConfig({ fontFamily: v as LabelConfig["fontFamily"] })}
                      options={[
                        { value: "roboto", label: "Roboto (recomendada)" },
                        { value: "roboto-condensed", label: "Roboto Condensed (compacta)" },
                        { value: "roboto-mono", label: "Roboto Mono (código)" },
                        { value: "ibm-plex-sans", label: "IBM Plex Sans" },
                        { value: "arial", label: "Arial" },
                      ]}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <label htmlFor="title-scale" className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                        Tamaño del título
                      </label>
                      <FieldSelect
                        id="title-scale"
                        value={config.titleScale}
                        onChange={(v) => updateConfig({ titleScale: v as LabelConfig["titleScale"] })}
                        options={[
                          { value: "sm", label: "Pequeño" },
                          { value: "md", label: "Normal" },
                          { value: "lg", label: "Grande" },
                          { value: "xl", label: "Extra grande" },
                        ]}
                      />
                    </div>
                    <div className="grid gap-2">
                      <label htmlFor="body-scale" className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                        Tamaño del texto
                      </label>
                      <FieldSelect
                        id="body-scale"
                        value={config.bodyScale}
                        onChange={(v) => updateConfig({ bodyScale: v as LabelConfig["bodyScale"] })}
                        options={[
                          { value: "sm", label: "Pequeño" },
                          { value: "md", label: "Normal" },
                          { value: "lg", label: "Grande" },
                        ]}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <label htmlFor="title-bold" className="text-base font-medium">
                      Título en negrita
                    </label>
                    <Switch id="title-bold" checked={config.titleBold} onChange={(v) => updateConfig({ titleBold: v })} />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <label htmlFor="body-bold" className="text-base font-medium">
                      Texto en negrita
                    </label>
                    <Switch id="body-bold" checked={config.bodyBold} onChange={(v) => updateConfig({ bodyBold: v })} />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <label htmlFor="uppercase" className="text-base font-medium">
                      Todo en mayúsculas
                    </label>
                    <Switch id="uppercase" checked={config.uppercaseAll} onChange={(v) => updateConfig({ uppercaseAll: v })} />
                  </div>
                  <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                    Las impresoras de red usan su propia letra; en ellas se aplican el tamaño y las mayúsculas.
                  </p>
                </div>

                <div className="h-px w-full" style={{ background: "var(--border)" }} />

                <div className="grid gap-4">
                  <div>
                    <p className="font-display text-lg font-bold">Diseño de la etiqueta</p>
                    <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                      Organiza el QR, el texto y las líneas de la etiqueta.
                    </p>
                  </div>
                  {config.includeQr && (
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <label htmlFor="qr-position" className="text-sm" style={{ color: "var(--muted-foreground)" }}>Posición del QR</label>
                        <FieldSelect
                          id="qr-position"
                          value={config.qrPosition || "right"}
                          onChange={(v) => updateConfig({ qrPosition: v as LabelConfig["qrPosition"] })}
                          options={[{ value: "right", label: "Derecha" }, { value: "left", label: "Izquierda" }]}
                        />
                      </div>
                      <div className="grid gap-2">
                        <label htmlFor="qr-size" className="text-sm" style={{ color: "var(--muted-foreground)" }}>Tamaño del QR</label>
                        <FieldSelect
                          id="qr-size"
                          value={config.qrSize || "md"}
                          onChange={(v) => updateConfig({ qrSize: v as LabelConfig["qrSize"] })}
                          options={[{ value: "sm", label: "Pequeño" }, { value: "md", label: "Mediano" }, { value: "lg", label: "Grande" }]}
                        />
                      </div>
                    </div>
                  )}
                  {config.includeQr && (
                    <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>El QR mide aproximadamente {qrPreviewMm.toFixed(1)} × {qrPreviewMm.toFixed(1)} mm.</p>
                  )}
                  <div className="grid gap-2">
                    <label htmlFor="body-align" className="text-sm" style={{ color: "var(--muted-foreground)" }}>Alineación del texto del cuerpo</label>
                    <FieldSelect
                      id="body-align"
                      value={config.bodyAlign || "center"}
                      onChange={(v) => updateConfig({ bodyAlign: v as LabelConfig["bodyAlign"] })}
                      options={[{ value: "left", label: "Izquierda" }, { value: "center", label: "Centrado" }, { value: "right", label: "Derecha" }]}
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <label htmlFor="div1" className="text-base font-medium">Línea bajo el título</label>
                    <Switch id="div1" checked={config.showHeaderDivider} onChange={(v) => updateConfig({ showHeaderDivider: v })} />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <label htmlFor="div2" className="text-base font-medium">Línea sobre el lema</label>
                    <Switch id="div2" checked={config.showFooterDivider} onChange={(v) => updateConfig({ showFooterDivider: v })} />
                  </div>
                  {(config.showHeaderDivider || config.showFooterDivider) && (
                    <div className="grid gap-2">
                      <label htmlFor="divider-style" className="text-sm" style={{ color: "var(--muted-foreground)" }}>Estilo de líneas</label>
                      <FieldSelect
                        id="divider-style"
                        value={config.dividerStyle}
                        onChange={(v) => updateConfig({ dividerStyle: v as LabelConfig["dividerStyle"] })}
                        options={[{ value: "solid", label: "Continuas" }, { value: "dashed", label: "Punteadas" }, { value: "none", label: "Sin líneas" }]}
                      />
                    </div>
                  )}
                  <LabelDesignEditor config={config} onChange={updateConfig} />
                </div>

                <div className="h-px w-full" style={{ background: "var(--border)" }} />

                <div className="grid gap-2">
                  <label htmlFor="preset" className="text-base font-medium">
                    Tamaño de etiqueta
                  </label>
                  <FieldSelect
                    id="preset"
                    value={config.presetId}
                    onChange={(v) => {
                      if (v === "custom") {
                        updateConfig({ presetId: "custom" });
                        return;
                      }
                      const p = LABEL_SIZE_PRESETS.find((x) => x.id === v);
                      if (p) updateConfig({ presetId: p.id, widthMm: p.widthMm, heightMm: p.heightMm });
                    }}
                    options={[
                      ...LABEL_SIZE_PRESETS.map((p) => ({ value: p.id, label: `${p.name} — ${p.subtitle}` })),
                      { value: "custom", label: "Personalizado…" },
                    ]}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <label htmlFor="w" className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                      Ancho (mm)
                    </label>
                    <input
                      id="w"
                      inputMode="numeric"
                      type="number"
                      min={25}
                      max={210}
                      value={config.widthMm}
                      onChange={(e) =>
                        updateConfig({ presetId: "custom", widthMm: Math.max(25, Math.min(210, Number(e.target.value) || 25)) })
                      }
                      className="h-11 w-full rounded-md border bg-transparent px-3 text-base shadow-xs outline-none focus:border-[var(--ring)] focus:ring-[3px] focus:ring-[var(--ring)]/50"
                      style={{ borderColor: "var(--input)" }}
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="h" className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                      Alto (mm)
                    </label>
                    <input
                      id="h"
                      inputMode="numeric"
                      type="number"
                      min={15}
                      max={297}
                      value={config.heightMm}
                      onChange={(e) =>
                        updateConfig({ presetId: "custom", heightMm: Math.max(15, Math.min(297, Number(e.target.value) || 15)) })
                      }
                      className="h-11 w-full rounded-md border bg-transparent px-3 text-base shadow-xs outline-none focus:border-[var(--ring)] focus:ring-[3px] focus:ring-[var(--ring)]/50"
                      style={{ borderColor: "var(--input)" }}
                    />
                  </div>
                </div>

                <div className="h-px w-full" style={{ background: "var(--border)" }} />

                <div className="grid gap-4">
                  <div>
                    <p className="font-display text-lg font-bold">Opciones de impresión</p>
                    <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Elige dónde imprimir y cómo acomodar las etiquetas.</p>
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="output" className="text-base font-medium">Salida</label>
                    <FieldSelect
                      id="output"
                      value={config.outputMode}
                      onChange={(v) => updateConfig({ outputMode: v as LabelConfig["outputMode"] })}
                      options={[
                        { value: "browser", label: "Impresora de etiquetas (una por página)" },
                        { value: "network", label: "Impresora de red (archivo ZPL)" },
                      ]}
                    />
                  </div>

                  {config.outputMode === "browser" && (
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <label htmlFor="paper" className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                          Papel
                        </label>
                        <FieldSelect
                          id="paper"
                          value={config.paperMode}
                          onChange={(v) => updateConfig({ paperMode: v as LabelConfig["paperMode"] })}
                          options={[
                            { value: "thermal", label: "Rollo térmico" },
                            { value: "a4", label: "Hoja A4" },
                            { value: "letter", label: "Hoja Carta" },
                          ]}
                        />
                      </div>
                      <div className="grid gap-2">
                        <label htmlFor="gap" className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                          Separación (mm)
                        </label>
                        <FieldSelect
                          id="gap"
                          value={String(config.sheetGapMm)}
                          onChange={(v) => updateConfig({ sheetGapMm: Number(v) })}
                          options={[
                            { value: "2", label: "2 mm" },
                            { value: "4", label: "4 mm" },
                            { value: "6", label: "6 mm" },
                            { value: "8", label: "8 mm" },
                          ]}
                        />
                      </div>
                    </div>
                  )}
                  {config.outputMode === "browser" && (
                    <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Para conservar las medidas usa escala 100 % y sin márgenes en el diálogo de impresión.</p>
                  )}
                  {config.outputMode === "network" && (
                    <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Puedes descargar el archivo ZPL desde la cola y enviarlo con tu utilidad de impresión de red.</p>
                  )}
                </div>

                <div className="grid gap-2">
                  <label htmlFor="footer" className="text-base font-medium">
                    Lema inferior
                  </label>
                  <input
                    id="footer"
                    maxLength={40}
                    placeholder="Sin lema"
                    value={config.footerText}
                    onChange={(e) => updateConfig({ footerText: e.target.value })}
                    className="h-11 w-full rounded-md border bg-transparent px-3 text-base shadow-xs outline-none focus:border-[var(--ring)] focus:ring-[3px] focus:ring-[var(--ring)]/50"
                    style={{ borderColor: "var(--input)" }}
                  />
                </div>

              </div>
            </section>

            {/* Impresora */}
            <section className="rounded-xl border shadow-xs" style={{ background: "var(--card)", borderColor: "var(--border)" }}>
              <header className="flex items-center justify-between gap-3 border-b px-5 py-4" style={{ borderColor: "var(--border)" }}>
                <div>
                  <h2 className="font-display text-xl font-bold">Impresora</h2>
                  <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                    {selectedPrinter ? `${selectedPrinter.ip}:${selectedPrinter.port} · ZPL · ${selectedPrinter.dpi} dpi` : "Sin impresoras"}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setIsAddingPrinter(true);
                    setEditingPrinter({ name: "", ip: "172.16.20.56", port: "9100", dpi: 203 });
                  }}
                  className="inline-flex h-8 items-center gap-1.5 rounded-md border bg-transparent px-3 text-sm font-medium shadow-xs transition-all hover:bg-[var(--accent)] cursor-pointer"
                  style={{ borderColor: "var(--input)" }}
                >
                  <Plus className="size-4" /> Agregar
                </button>
              </header>
              <div className="grid gap-3 p-5">
                <label htmlFor="printer" className="sr-only">
                  Impresora seleccionada
                </label>
                <FieldSelect
                  id="printer"
                  value={selectedPrinterId}
                  onChange={setSelectedPrinterId}
                  options={printers.map((p) => ({ value: p.id, label: `${p.name} — ${p.ip}:${p.port}` }))}
                />
                <p className="flex items-start gap-2 text-sm" style={{ color: "var(--muted-foreground)" }}>
                  <Laptop className="mt-0.5 size-4 shrink-0" />
                  Dirección IP o DNS local. El puerto 9100 requiere un puente de impresión; sin él se descarga el archivo ZPL.
                </p>

                {(isAddingPrinter || editingPrinter?.id) && editingPrinter && (
                  <div className="grid gap-2 rounded-lg border p-3" style={{ borderColor: "var(--input)", background: "var(--background)" }}>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        placeholder="Nombre (ej. Zebra Almacén)"
                        value={editingPrinter.name || ""}
                        onChange={(e) => setEditingPrinter((p) => ({ ...p, name: e.target.value }))}
                        className="col-span-2 h-10 rounded-md border bg-white px-3 text-sm outline-none focus:border-[var(--ring)]"
                        style={{ borderColor: "var(--input)" }}
                      />
                      <label className="grid gap-1 text-xs font-medium">
                        DNS o dirección IP
                        <input
                          placeholder="172.16.20.56 o impresora.local"
                          value={editingPrinter.ip || ""}
                          onChange={(e) => setEditingPrinter((p) => ({ ...p, ip: e.target.value }))}
                          className="h-10 min-w-0 rounded-md border bg-white px-3 font-mono text-sm outline-none focus:border-[var(--ring)]"
                          style={{ borderColor: "var(--input)" }}
                        />
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          placeholder="9100"
                          value={editingPrinter.port || ""}
                          onChange={(e) => setEditingPrinter((p) => ({ ...p, port: e.target.value }))}
                          className="h-10 rounded-md border bg-white px-3 font-mono text-sm outline-none focus:border-[var(--ring)]"
                          style={{ borderColor: "var(--input)" }}
                        />
                        <select
                          value={editingPrinter.dpi || 203}
                          onChange={(e) => setEditingPrinter((p) => ({ ...p, dpi: Number(e.target.value) as 203 | 300 }))}
                          className="h-10 rounded-md border bg-white px-2 text-sm outline-none"
                          style={{ borderColor: "var(--input)" }}
                        >
                          <option value={203}>203 dpi</option>
                          <option value={300}>300 dpi</option>
                        </select>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const host = editingPrinter.ip?.trim() || "";
                          if (!host || !/^[a-z0-9.-]+$/i.test(host) || host.startsWith(".") || host.endsWith(".")) {
                            setToast({ title: "Ingresa una IP o DNS válido", desc: "Ejemplo: 172.16.20.56 o impresora.local", kind: "err" });
                            return;
                          }
                          if (editingPrinter.id) {
                            setPrinters((prev) => prev.map((p) => (p.id === editingPrinter.id ? ({ ...p, ...editingPrinter, ip: host } as NetworkPrinter) : p)));
                            setToast({ title: "Impresora actualizada", kind: "ok" });
                          } else {
                            const np: NetworkPrinter = {
                              id: `printer-${Date.now()}`,
                              name: editingPrinter.name?.trim() || `Impresora ${printers.length + 1}`,
                              ip: host,
                              port: editingPrinter.port?.trim() || "9100",
                              dpi: (editingPrinter.dpi as 203 | 300) || 203,
                            };
                            setPrinters((prev) => [...prev, np]);
                            setSelectedPrinterId(np.id);
                            setToast({ title: "Impresora agregada", kind: "ok" });
                          }
                          setEditingPrinter(null);
                          setIsAddingPrinter(false);
                        }}
                        className="h-9 flex-1 rounded-md text-sm font-semibold cursor-pointer"
                        style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
                      >
                        Guardar
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingPrinter(null);
                          setIsAddingPrinter(false);
                        }}
                        className="h-9 rounded-md border px-4 text-sm cursor-pointer hover:bg-[var(--accent)]"
                        style={{ borderColor: "var(--input)" }}
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={handleTestLabel}
                    disabled={sending || !selectedPrinter}
                    className="inline-flex h-8 items-center gap-1.5 rounded-md border bg-transparent px-3 text-sm font-medium shadow-xs transition-all hover:bg-[var(--accent)] disabled:opacity-50 cursor-pointer"
                    style={{ borderColor: "var(--input)" }}
                  >
                    {sending ? <Loader2 className="size-4 animate-spin" /> : <Printer className="size-4" />}
                    Etiqueta de prueba
                  </button>
                  <button
                    type="button"
                    disabled={!selectedPrinter}
                    onClick={() => {
                      if (selectedPrinter) {
                        setEditingPrinter({ ...selectedPrinter });
                        setIsAddingPrinter(false);
                      }
                    }}
                    className="inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-sm font-medium transition-all hover:bg-[var(--accent)] disabled:opacity-50 cursor-pointer"
                  >
                    <Pencil className="size-4" /> Editar
                  </button>
                  <button
                    type="button"
                    disabled={!selectedPrinter || printers.length <= 1}
                    onClick={() => {
                      if (!selectedPrinter) return;
                      setPrinters((prev) => prev.filter((p) => p.id !== selectedPrinter.id));
                      const next = printers.find((p) => p.id !== selectedPrinter.id);
                      if (next) setSelectedPrinterId(next.id);
                    }}
                    className="inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-sm font-medium transition-all hover:bg-[var(--accent)] disabled:opacity-50 cursor-pointer"
                  >
                    <Trash2 className="size-4" /> Quitar
                  </button>
                </div>
              </div>
            </section>

            {/* Imported files stay available in this browser. */}
            <section className="rounded-xl border shadow-xs" style={{ background: "var(--card)", borderColor: "var(--border)" }}>
              <header className="border-b px-5 py-4" style={{ borderColor: "var(--border)" }}>
                <h2 className="font-display text-xl font-bold">Archivos importados</h2>
                <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                  {importedFileNames.length === 0
                    ? "Todavía no has importado un Excel"
                    : `${importedFileNames.length} archivo${importedFileNames.length === 1 ? "" : "s"} guardado${importedFileNames.length === 1 ? "" : "s"} en este navegador`}
                </p>
              </header>
              <div className="grid gap-3 p-5">
                {importedFileNames.length > 0 && (
                  <ul className="max-h-28 overflow-y-auto nice-scroll text-sm" style={{ color: "var(--muted-foreground)" }}>
                    {importedFileNames.map((name) => <li key={name} className="truncate py-0.5" title={name}>{name}</li>)}
                  </ul>
                )}
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    disabled={!catalogReady || importing}
                    className="inline-flex h-9 items-center gap-2 rounded-md border px-3 text-sm font-medium hover:bg-[var(--accent)] disabled:opacity-50 cursor-pointer"
                    style={{ borderColor: "var(--input)" }}
                  >
                    <FileSpreadsheet className="size-4" /> Importar otro Excel
                  </button>
                  <button
                    type="button"
                    onClick={() => downloadCatalogBackup(materials)}
                    disabled={materials.length === 0}
                    className="inline-flex h-9 items-center gap-2 rounded-md border px-3 text-sm font-medium hover:bg-[var(--accent)] disabled:opacity-50 cursor-pointer"
                    style={{ borderColor: "var(--input)" }}
                  >
                    <Download className="size-4" /> Descargar respaldo
                  </button>
                </div>
              </div>
            </section>

            {/* Cola */}
            <section className="rounded-xl border shadow-xs" style={{ background: "var(--card)", borderColor: "var(--border)" }}>
              <header className="flex items-center justify-between gap-3 border-b px-5 py-4" style={{ borderColor: "var(--border)" }}>
                <div>
                  <h2 className="font-display text-xl font-bold">Cola de impresión</h2>
                  <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                    {queueDetailed.length === 0 ? "Vacía" : `${totalQueueLabels} etiqueta(s) · ${queueDetailed.length} material(es)`}
                  </p>
                </div>
                {queueDetailed.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setQueue([])}
                    className="text-sm font-medium hover:underline cursor-pointer"
                    style={{ color: "var(--muted-foreground)" }}
                  >
                    Vaciar
                  </button>
                )}
              </header>

              {queueDetailed.length === 0 ? (
                <p className="px-5 py-8 text-center text-sm" style={{ color: "var(--muted-foreground)" }}>
                  Toca un material del catálogo para agregarlo a la cola.
                </p>
              ) : (
                <ul className="max-h-72 divide-y overflow-y-auto nice-scroll" style={{ borderColor: "var(--border)" }}>
                  {queueDetailed.map(({ entry, material }) => (
                    <li key={entry.materialId} className="flex items-center gap-3 px-5 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-mono text-sm font-semibold" style={{ fontFamily: "var(--font-code)" }}>
                          {material.codigo}
                        </p>
                        <p className="truncate text-xs" style={{ color: "var(--muted-foreground)" }}>
                          {material.descripcion}
                        </p>
                      </div>
                      <div className="flex items-center rounded-md border" style={{ borderColor: "var(--input)" }}>
                        <button
                          type="button"
                          aria-label="Quitar uno"
                          onClick={() => (entry.qty <= 1 ? removeFromQueue(entry.materialId) : setQty(entry.materialId, entry.qty - 1))}
                          className="grid size-8 place-items-center hover:bg-[var(--accent)] cursor-pointer"
                        >
                          <Minus className="size-3.5" />
                        </button>
                        <input
                          type="number"
                          min={1}
                          max={999}
                          value={entry.qty}
                          onChange={(e) => setQty(entry.materialId, Number(e.target.value))}
                          className="w-10 text-center font-mono text-sm outline-none"
                          style={{ fontFamily: "var(--font-code)" }}
                        />
                        <button
                          type="button"
                          aria-label="Agregar uno"
                          onClick={() => setQty(entry.materialId, entry.qty + 1)}
                          className="grid size-8 place-items-center hover:bg-[var(--accent)] cursor-pointer"
                        >
                          <Plus className="size-3.5" />
                        </button>
                      </div>
                      <button
                        type="button"
                        aria-label="Quitar de la cola"
                        onClick={() => removeFromQueue(entry.materialId)}
                        className="grid size-8 place-items-center rounded-md hover:bg-[var(--accent)] cursor-pointer"
                        style={{ color: "var(--muted-foreground)" }}
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}

              <div className="border-t p-4" style={{ borderColor: "var(--border)" }}>
                <button
                  type="button"
                  onClick={handlePrint}
                  disabled={queueDetailed.length === 0 || sending}
                  className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-md px-6 text-base font-semibold transition-all hover:brightness-95 disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
                  style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
                >
                  {sending ? <Loader2 className="size-5 animate-spin" /> : <Printer className="size-5" />}
                  {config.outputMode === "network" ? "Enviar a impresora de red" : "Imprimir etiquetas"}
                  {totalQueueLabels > 0 ? ` (${totalQueueLabels})` : ""}
                </button>
                {config.outputMode === "network" && queueDetailed.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      if (!selectedPrinter) return;
                      const qtyMap = new Map(queueDetailed.map((q) => [q.material.id, q.entry.qty] as [string, number]));
                      const zpl = buildZplBatch(
                        queueDetailed.map((q) => q.material),
                        qtyMap,
                        config,
                        selectedPrinter
                      );
                      downloadTextFile(`etiquetas_${config.widthMm}x${config.heightMm}mm.zpl`, zpl);
                    }}
                    className="mt-2 inline-flex h-9 w-full items-center justify-center gap-2 rounded-md border text-sm font-medium hover:bg-[var(--accent)] cursor-pointer"
                    style={{ borderColor: "var(--input)" }}
                  >
                    <Download className="size-4" /> Descargar archivo .zpl
                  </button>
                )}
              </div>
            </section>
          </aside>
        </main>

        {/* Toast */}
        {toast && (
          <div className="fixed right-4 bottom-4 z-50 w-[calc(100%-2rem)] max-w-sm rounded-xl border bg-white p-4 shadow-2xl" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-start gap-3">
              <span
                className="grid size-8 shrink-0 place-items-center rounded-full"
                style={{
                  background: toast.kind === "ok" ? "var(--primary)" : "#FEE2E2",
                  color: toast.kind === "ok" ? "var(--primary-foreground)" : "#B91C1C",
                }}
              >
                {toast.kind === "ok" ? <Check className="size-4" /> : <X className="size-4" />}
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-neutral-900">{toast.title}</p>
                {toast.desc && <p className="mt-0.5 truncate text-xs text-neutral-600">{toast.desc}</p>
                }
              </div>
            </div>
          </div>
        )}
      </div>

      {pendingExcel && (
        <ExcelImportDialog
          parsed={pendingExcel}
          saving={importing}
          onClose={() => setPendingExcel(null)}
          onSave={confirmExcelImport}
        />
      )}
      <PrintSheetArea labelsToPrint={printLabels} config={config} />
    </>
  );
}
