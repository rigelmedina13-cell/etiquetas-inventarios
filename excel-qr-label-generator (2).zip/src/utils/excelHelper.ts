import * as XLSX from "xlsx";
import { ColumnMapping, MaterialItem } from "../types/label";

function normalizeHeader(header: string): string {
  return header
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

export function detectColumnMapping(headers: string[]): ColumnMapping {
  const findMatch = (keywords: string[], exclude: string[] = []): string => {
    // 1. Exact normalized match
    for (const kw of keywords) {
      const exact = headers.find(
        (h) => !exclude.includes(h) && normalizeHeader(h) === kw
      );
      if (exact) return exact;
    }
    // 2. Substring match
    for (const kw of keywords) {
      const partial = headers.find(
        (h) => !exclude.includes(h) && normalizeHeader(h).includes(kw)
      );
      if (partial) return partial;
    }
    return "";
  };

  const used: string[] = [];

  const codigo =
    findMatch(
      [
        "codigo",
        "code",
        "sku",
        "clave",
        "id",
        "referencia",
        "ref",
        "parte",
        "part",
        "numero",
        "folio",
      ],
      used
    ) || headers[0] || "";
  if (codigo) used.push(codigo);

  const descripcion =
    findMatch(
      [
        "descripcion",
        "description",
        "material",
        "nombre",
        "articulo",
        "producto",
        "detalle",
        "concepto",
        "item",
        "name",
      ],
      used
    ) || headers.find((h) => !used.includes(h)) || "";
  if (descripcion) used.push(descripcion);

  const categoria = findMatch(
    ["categoria", "category", "familia", "grupo", "tipo", "linea", "clase"],
    used
  );
  if (categoria) used.push(categoria);

  const ubicacion = findMatch(
    [
      "ubicacion",
      "location",
      "almacen",
      "pasillo",
      "estante",
      "rack",
      "bodega",
      "zona",
      "anaquel",
      "posicion",
    ],
    used
  );
  if (ubicacion) used.push(ubicacion);

  const unidad = findMatch(
    ["unidad", "unit", "um", "uom", "medida", "presentacion", "empaque"],
    used
  );
  if (unidad) used.push(unidad);

  const lote = findMatch(
    ["lote", "lot", "serie", "serial", "batch", "colada", "caducidad"],
    used
  );
  if (lote) used.push(lote);

  return {
    codigo,
    descripcion,
    categoria,
    ubicacion,
    unidad,
    lote,
  };
}

export interface ParsedWorkbookData {
  fileName: string;
  workbook: XLSX.WorkBook;
  sheetNames: string[];
  activeSheet: string;
  headers: string[];
  rawRows: Record<string, unknown>[];
  mapping: ColumnMapping;
}

export function extractSheetData(
  workbook: XLSX.WorkBook,
  sheetName: string
): {
  headers: string[];
  rawRows: Record<string, unknown>[];
  mapping: ColumnMapping;
} {
  const worksheet = workbook.Sheets[sheetName];
  if (!worksheet) {
    return {
      headers: [],
      rawRows: [],
      mapping: {
        codigo: "",
        descripcion: "",
        categoria: "",
        ubicacion: "",
        unidad: "",
        lote: "",
      },
    };
  }

  // Extract raw rows as objects
  const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet, {
    defval: "",
    raw: false,
  });

  // Collect all unique header keys preserving order
  const headerSet = new Set<string>();
  for (const row of rawRows) {
    Object.keys(row).forEach((k) => {
      if (k && !k.startsWith("__EMPTY")) {
        headerSet.add(k);
      }
    });
  }

  // Fallback: if all columns were __EMPTY or empty, include them
  if (headerSet.size === 0 && rawRows.length > 0) {
    Object.keys(rawRows[0]).forEach((k) => headerSet.add(k));
  }

  const headers = Array.from(headerSet);
  const mapping = detectColumnMapping(headers);

  return { headers, rawRows, mapping };
}

export async function parseExcelFile(file: File): Promise<ParsedWorkbookData> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array" });
  const sheetNames = workbook.SheetNames;
  const activeSheet = sheetNames[0] || "";
  const { headers, rawRows, mapping } = extractSheetData(workbook, activeSheet);

  return {
    fileName: file.name,
    workbook,
    sheetNames,
    activeSheet,
    headers,
    rawRows,
    mapping,
  };
}

export function mapRowsToMaterials(
  rawRows: Record<string, unknown>[],
  mapping: ColumnMapping,
  allHeaders: string[]
): MaterialItem[] {
  const mappedHeaders = new Set(
    [
      mapping.codigo,
      mapping.descripcion,
      mapping.categoria,
      mapping.ubicacion,
      mapping.unidad,
      mapping.lote,
    ].filter(Boolean)
  );

  const extraHeaders = allHeaders.filter((h) => !mappedHeaders.has(h));

  return rawRows
    .map((row, idx): MaterialItem | null => {
      const getVal = (col: string): string => {
        if (!col) return "";
        const val = row[col];
        return val !== undefined && val !== null ? String(val).trim() : "";
      };

      const codigo = getVal(mapping.codigo);
      const descripcion = getVal(mapping.descripcion);

      // Skip completely empty rows
      if (!codigo && !descripcion) {
        return null;
      }

      const extraFields: Record<string, string> = {};
      for (const eh of extraHeaders) {
        const val = getVal(eh);
        // Preserve empty Excel columns so they remain selectable in the editor.
        extraFields[eh] = val;
      }

      return {
        id: `xls-${Date.now()}-${idx}`,
        codigo: codigo || `ITEM-${idx + 1}`,
        descripcion: descripcion || "Sin descripción",
        categoria: getVal(mapping.categoria) || undefined,
        ubicacion: getVal(mapping.ubicacion) || undefined,
        unidad: getVal(mapping.unidad) || undefined,
        lote: getVal(mapping.lote) || undefined,
        extraFields,
      };
    })
    .filter((item): item is MaterialItem => item !== null);
}

export function downloadCatalogBackup(materials: MaterialItem[]): void {
  if (materials.length === 0) return;
  const rows = materials.map((material) => ({
    Codigo: material.codigo,
    Descripcion: material.descripcion,
    Categoria: material.categoria || "",
    Ubicacion: material.ubicacion || "",
    Unidad: material.unidad || "",
    Lote: material.lote || "",
    ...material.extraFields,
  }));
  const sheet = XLSX.utils.json_to_sheet(rows);
  sheet["!cols"] = [{ wch: 22 }, { wch: 60 }, { wch: 25 }, { wch: 22 }, { wch: 12 }, { wch: 20 }];
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, "Materiales");
  XLSX.writeFileXLSX(book, "respaldo_catalogo_materiales.xlsx");
}

export function downloadExcelTemplate(): void {
  const sampleRows = [
    {
      Codigo: "MAT-10482-AC",
      Descripcion: "Tornillo hexagonal acero inoxidable M8 x 40mm DIN 933",
      Categoria: "Fijación y Tornillería",
      Ubicacion: "PASILLO A-04",
      Unidad: "PZA",
      Lote: "LOT-2026-014",
      Proveedor: "Fijaciones del Norte",
    },
    {
      Codigo: "ELC-20910-CB",
      Descripcion: "Cable eléctrico calibre 12 AWG THW-LS antiflama negro 100m",
      Categoria: "Material Eléctrico",
      Ubicacion: "ESTANTE B-11",
      Unidad: "ROLLO",
      Lote: "LOT-2026-089",
      Proveedor: "Conductores MX",
    },
    {
      Codigo: "TUB-33105-PV",
      Descripcion: "Válvula de esfera PVC hidráulico cédula 80 de 2 pulgadas",
      Categoria: "Tubería y Válvulas",
      Ubicacion: "RACK C-02",
      Unidad: "PZA",
      Lote: "LOT-2026-041",
      Proveedor: "HidroSistemas",
    },
    {
      Codigo: "ACE-44820-PL",
      Descripcion: "Placa de acero al carbón A36 espesor 1/4 pulgada",
      Categoria: "Acero y Metales",
      Ubicacion: "ZONA D-01",
      Unidad: "PZA",
      Lote: "COL-88412",
      Proveedor: "Aceros Industriales",
    },
    {
      Codigo: "SEG-55019-GT",
      Descripcion: "Guante de seguridad anticorte nivel 5 recubrimiento nitrilo",
      Categoria: "Seguridad Industrial",
      Ubicacion: "GABINETE E-06",
      Unidad: "PAR",
      Lote: "LOT-2026-102",
      Proveedor: "ProSeguridad",
    },
  ];

  const worksheet = XLSX.utils.json_to_sheet(sampleRows);
  worksheet["!cols"] = [
    { wch: 18 },
    { wch: 52 },
    { wch: 24 },
    { wch: 16 },
    { wch: 10 },
    { wch: 16 },
    { wch: 22 },
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Materiales");
  XLSX.writeFileXLSX(workbook, "plantilla_catalogo_materiales.xlsx");
}
