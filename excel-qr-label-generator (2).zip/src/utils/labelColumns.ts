import { ColumnMapping, MaterialItem } from "../types/label";

export interface LabelColumn {
  key: string;
  label: string;
}

export const CORE_COLUMNS: LabelColumn[] = [
  { key: "codigo", label: "Número del material" },
  { key: "descripcion", label: "Descripción" },
  { key: "ubicacion", label: "Ubicación" },
  { key: "unidad", label: "Unidad" },
  { key: "categoria", label: "Categoría" },
  { key: "lote", label: "Lote / Serie" },
];

export function columnKeyFromHeader(header: string, mapping: ColumnMapping): string {
  const match = (Object.keys(mapping) as (keyof ColumnMapping)[]).find((key) => mapping[key] === header);
  return match || `extra:${header}`;
}

export function getAvailableColumns(materials: MaterialItem[]): LabelColumn[] {
  const cols: LabelColumn[] = CORE_COLUMNS.slice(0, 2);
  const extraKeys = new Set<string>();
  materials.forEach((m) => {
    Object.keys(m.extraFields || {}).forEach((k) => {
      if (k && k.trim()) extraKeys.add(k);
    });
  });
  // Keep spreadsheet order and place Excel columns right after the main fields.
  Array.from(extraKeys).forEach((k) => cols.push({ key: `extra:${k}`, label: k }));
  cols.push(...CORE_COLUMNS.slice(2));
  return cols;
}

export function getColumnLabel(key: string, materials?: MaterialItem[]): string {
  if (key === "__none__") return "Ninguno";
  if (key === "__title__") return "Mismo que el título";
  const core = CORE_COLUMNS.find((c) => c.key === key);
  if (core) return core.label;
  if (key.startsWith("extra:")) return key.slice(6);
  if (materials) {
    const found = getAvailableColumns(materials).find((c) => c.key === key);
    if (found) return found.label;
  }
  return key;
}

export function getFieldValue(material: MaterialItem, key: string): string {
  if (!material || !key) return "";
  if (key === "__none__") return "";
  if (key === "__title__") return "";
  if (key === "codigo") return material.codigo || "";
  if (key === "descripcion") return material.descripcion || "";
  if (key === "ubicacion") return material.ubicacion || "";
  if (key === "unidad") return material.unidad || "";
  if (key === "categoria") return material.categoria || "";
  if (key === "lote") return material.lote || "";
  if (key.startsWith("extra:")) {
    const name = key.slice(6);
    return material.extraFields?.[name] || "";
  }
  return material.extraFields?.[key] || "";
}
