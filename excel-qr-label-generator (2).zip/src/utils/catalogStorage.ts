import { MaterialItem } from "../types/label";

export interface SavedCatalog {
  materials: MaterialItem[];
  fileNames: string[];
  updatedAt: string;
  visibleColumns?: string[];
}

const DB_NAME = "etiquetas-inventarios";
const STORE_NAME = "catalogos";
const CATALOG_KEY = "materiales";
const FALLBACK_KEY = "inv_labels_catalog_v1";

function openCatalogDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE_NAME)) {
        request.result.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("No se pudo abrir el catálogo local."));
  });
}

export async function loadCatalog(): Promise<SavedCatalog | null> {
  if (typeof indexedDB === "undefined") {
    const saved = localStorage.getItem(FALLBACK_KEY);
    return saved ? (JSON.parse(saved) as SavedCatalog) : null;
  }

  const db = await openCatalogDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const request = tx.objectStore(STORE_NAME).get(CATALOG_KEY);
      request.onsuccess = () => resolve((request.result as SavedCatalog | undefined) || null);
      request.onerror = () => reject(request.error || new Error("No se pudo leer el catálogo."));
    });
  } finally {
    db.close();
  }
}

export async function saveCatalog(snapshot: SavedCatalog): Promise<void> {
  if (typeof indexedDB === "undefined") {
    localStorage.setItem(FALLBACK_KEY, JSON.stringify(snapshot));
    return;
  }

  const db = await openCatalogDb();
  try {
    // Resolve only after the whole transaction commits, not just after put().
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(snapshot, CATALOG_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error("No se pudo guardar el catálogo."));
      tx.onabort = () => reject(tx.error || new Error("Se canceló el guardado del catálogo."));
    });
  } finally {
    db.close();
  }
}

export async function clearCatalog(): Promise<void> {
  if (typeof indexedDB === "undefined") {
    localStorage.removeItem(FALLBACK_KEY);
    return;
  }

  const db = await openCatalogDb();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).delete(CATALOG_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error("No se pudo borrar el catálogo."));
      tx.onabort = () => reject(tx.error || new Error("Se canceló el borrado del catálogo."));
    });
  } finally {
    db.close();
  }
}

export function mergeMaterials(existing: MaterialItem[], imported: MaterialItem[]): MaterialItem[] {
  const next = [...existing];
  const byCode = new Map(existing.map((material, index) => [material.codigo.trim().toLocaleLowerCase(), index]));

  for (const material of imported) {
    const code = material.codigo.trim().toLocaleLowerCase();
    const index = byCode.get(code);
    if (index !== undefined) {
      const previous = next[index];
      next[index] = {
        ...previous,
        ...material,
        id: previous.id,
        extraFields: { ...previous.extraFields, ...material.extraFields },
      };
    } else {
      byCode.set(code, next.length);
      next.push(material);
    }
  }
  return next;
}