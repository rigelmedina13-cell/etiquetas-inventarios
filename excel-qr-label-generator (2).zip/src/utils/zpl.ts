import QRCode from "qrcode";
import { LabelConfig, MaterialItem, NetworkPrinter } from "../types/label";
import { getColumnLabel, getFieldValue } from "./labelColumns";
import { getAvailableTopMm, getDesiredQrMm } from "../components/LabelRenderer";

function sanitizeZpl(text: string): string {
  return (text || "")
    .replace(/\^/g, "")
    .replace(/~/g, "")
    .replace(/\r?\n/g, " ")
    .trim();
}

function wrapWords(text: string, maxChars: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length === 0) return [""];
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    if ((cur ? cur.length + 1 + w.length : w.length) <= maxChars) {
      cur = cur ? `${cur} ${w}` : w;
    } else {
      if (cur) lines.push(cur);
      if (w.length > maxChars) {
        for (let i = 0; i < w.length; i += maxChars) {
          lines.push(w.slice(i, i + maxChars));
        }
        cur = "";
      } else {
        cur = w;
      }
    }
  }
  if (cur) lines.push(cur);
  return lines;
}

export function mmToDots(mm: number, dpi: 203 | 300): number {
  return Math.round((mm / 25.4) * dpi);
}

export function buildZplForMaterial(
  material: MaterialItem,
  config: LabelConfig,
  printer: NetworkPrinter
): string {
  const dpi = printer.dpi;
  const labelW = mmToDots(config.widthMm, dpi);
  const labelH = mmToDots(config.heightMm, dpi);
  const margin = mmToDots(config.horizontalPaddingMm ?? 2.4, dpi);

  const rawTitle = getFieldValue(material, config.titleField) || "—";
  const title = config.uppercaseAll ? rawTitle.toUpperCase() : rawTitle;

  const bodyTexts: string[] = [];
  for (const key of config.bodyFields) {
    const v = getFieldValue(material, key).trim();
    if (!v) continue;
    const t = config.uppercaseAll ? v.toUpperCase() : v;
    if (config.showFieldNames) {
      const name = getColumnLabel(key);
      const n = config.uppercaseAll ? name.toUpperCase() : name;
      bodyTexts.push(`${n}: ${t}`);
    } else {
      bodyTexts.push(t);
    }
  }

  const qrValue =
    config.qrField === "__title__"
      ? title
      : getFieldValue(material, config.qrField) || material.codigo;

  const footer = (config.footerText || "").toUpperCase().slice(0, 40);

  const titleFontH = config.titleFontPt != null
    ? Math.round(config.titleFontPt * dpi / 72)
    : config.titleScale === "sm"
      ? Math.round(labelH * 0.16)
      : config.titleScale === "md"
      ? Math.round(labelH * 0.2)
      : config.titleScale === "xl"
      ? Math.round(labelH * 0.3)
      : Math.round(labelH * 0.25);
  const titleFontW = Math.round(titleFontH * 0.85);

  const bodyFontH = config.bodyFontPt != null
    ? Math.round(config.bodyFontPt * dpi / 72)
    : config.bodyScale === "sm"
      ? Math.round(labelH * 0.075)
      : config.bodyScale === "lg"
      ? Math.round(labelH * 0.11)
      : Math.round(labelH * 0.09);
  const bodyFontW = Math.round(bodyFontH * 0.85);
  const footerFontH = config.footerFontPt != null
    ? Math.round(config.footerFontPt * dpi / 72)
    : Math.round(labelH * 0.065);
  const footerFontW = Math.round(footerFontH * 0.85);

  // QR: mismo tamaño en mm que la vista previa + magnificación dinámica ZPL
  const hasBodyForQr = bodyTexts.length > 0;
  const hasFooterForQr = Boolean(footer.trim());
  const hasTopForQr = config.titleField !== "__none__" || config.includeQr;
  const hasMiddleForQr = hasBodyForQr;
  const showHeaderDividerForQr =
    config.showHeaderDivider &&
    config.dividerStyle !== "none" &&
    hasTopForQr &&
    (hasMiddleForQr || hasFooterForQr);
  const showFooterDividerForQr =
    config.showFooterDivider &&
    config.dividerStyle !== "none" &&
    hasFooterForQr &&
    (hasTopForQr || hasMiddleForQr);
  const availableTopMm = getAvailableTopMm(
    config,
    hasBodyForQr,
    hasFooterForQr,
    showHeaderDividerForQr,
    showFooterDividerForQr
  );
  const desiredQrMm = config.includeQr ? getDesiredQrMm(config, availableTopMm) : 0;
  const qrSize = config.includeQr ? mmToDots(desiredQrMm, dpi) : 0;
  const qrX = config.qrPosition === "left" ? margin : labelW - margin - qrSize;
  const titleX = config.includeQr && config.qrPosition === "left" ? margin * 2 + qrSize : margin;
  const titleMaxW = config.includeQr ? labelW - margin * 3 - qrSize : labelW - margin * 2;

  const qrModuleCount = (() => {
    if (!config.includeQr) return 25;
    try {
      const q = QRCode.create(sanitizeZpl(qrValue) || "SIN-CODIGO", { errorCorrectionLevel: "M" });
      return q.modules.size || 25;
    } catch {
      return 25;
    }
  })();
  // +2 módulos de zona silenciosa como en la vista previa SVG
  const dotMm = 25.4 / dpi;
  const qrMag = config.includeQr
    ? Math.max(1, Math.min(10, Math.round(desiredQrMm / ((qrModuleCount + 2) * dotMm))))
    : 3;

  // Estimación de caracteres por línea según ancho
  const titleCharsPerLine = Math.max(6, Math.floor(titleMaxW / (titleFontW * 0.75)));
  const titleLines = wrapWords(sanitizeZpl(title), titleCharsPerLine).slice(0, 2);

  const bodyCharsPerLine = Math.max(10, Math.floor((labelW - margin * 2) / (bodyFontW * 0.72)));
  const wrappedBody: string[] = [];
  for (const b of bodyTexts) {
    wrappedBody.push(...wrapWords(sanitizeZpl(b), bodyCharsPerLine));
  }
  const bodyLines = wrappedBody.slice(0, 4);

  let y = mmToDots(config.verticalPaddingMm ?? 1.6, dpi);
  let zpl = `^XA\n^PW${labelW}\n^LL${labelH}\n^LH0,0\n`;
  if (config.showBorder) zpl += `^FO0,0^GB${labelW},${labelH},2^FS\n`;

  // Título (arriba, centrado en zona izquierda si hay QR)
  titleLines.forEach((line, i) => {
    const lineY = y + i * Math.round(titleFontH * 1.05);
    if (config.includeQr) {
      // Centrado aproximado en la zona del título
      const estW = line.length * titleFontW * 0.62;
      const x = config.titleAlign === "left"
        ? titleX
        : config.titleAlign === "right"
        ? Math.max(titleX, Math.round(titleX + titleMaxW - estW))
        : Math.max(titleX, Math.round(titleX + (titleMaxW - estW) / 2));
      zpl += `^FO${x},${lineY}^A0N,${titleFontH},${titleFontW}^FD${line}^FS\n`;
    } else {
      const titleAlign = config.titleAlign === "left" ? "L" : config.titleAlign === "right" ? "R" : "C";
      zpl += `^FO${margin},${lineY}^A0N,${titleFontH},${titleFontW}^FB${labelW - margin * 2},1,0,${titleAlign},0^FD${line}^FS\n`;
    }
  });
  y += titleLines.length * Math.round(titleFontH * 1.05) + Math.round(labelH * 0.03);

  // QR a la derecha — magnificación calculada para dar desiredQrMm físicos
  if (config.includeQr) {
    const qrY = mmToDots(config.verticalPaddingMm ?? 1.6, dpi);
    zpl += `^FO${qrX},${qrY}^BQN,2,${qrMag}^FDQA,${sanitizeZpl(qrValue)}^FS\n`;
  }

  // Línea divisoria superior
  if (config.showHeaderDivider && config.dividerStyle !== "none") {
    const th = Math.max(2, Math.round(labelH * 0.008));
    zpl += `^FO0,${y}^GB${labelW},${th},${th}^FS\n`;
    y += th + Math.round(labelH * 0.04);
  }

  // Cuerpo centrado
  const bodyAlign = config.bodyAlign === "left" ? "L" : config.bodyAlign === "right" ? "R" : "C";
  for (const line of bodyLines) {
    zpl += `^FO${margin},${y}^A0N,${bodyFontH},${bodyFontW}^FB${labelW - margin * 2},1,0,${bodyAlign},0^FD${line}^FS\n`;
    y += Math.round(bodyFontH * 1.25);
  }

  // Línea inferior + lema
  if (hasFooter(footer) && config.showFooterDivider && config.dividerStyle !== "none") {
    const th = Math.max(2, Math.round(labelH * 0.008));
    const lineY = labelH - Math.round(footerFontH * 1.9) - Math.round(labelH * 0.03);
    zpl += `^FO0,${lineY}^GB${labelW},${th},${th}^FS\n`;
  }
  if (hasFooter(footer)) {
    const fy = labelH - Math.round(footerFontH * 1.4);
    // Lema con espaciado: insertamos espacios finos entre letras
    const spaced = footer.split("").join((config.footerTrackingEm ?? 0.42) >= 0.3 ? " " : "");
    zpl += `^FO${margin},${fy}^A0N,${footerFontH},${footerFontW}^FB${labelW - margin * 2},1,0,C,0^FD${sanitizeZpl(spaced)}^FS\n`;
  }

  zpl += `^XZ`;
  return zpl;
}

function hasFooter(footer: string): boolean {
  return Boolean(footer && footer.trim());
}

export function buildZplBatch(
  materials: MaterialItem[],
  quantities: Map<string, number>,
  config: LabelConfig,
  printer: NetworkPrinter
): string {
  const chunks: string[] = [];
  for (const m of materials) {
    const qty = quantities.get(m.id) ?? 1;
    for (let i = 0; i < qty; i++) {
      chunks.push(buildZplForMaterial(m, config, printer));
    }
  }
  return chunks.join("\n");
}

export async function sendZplToPrinter(zpl: string, printer: NetworkPrinter): Promise<void> {
  // A web browser cannot open a raw TCP socket to Zebra port 9100.
  if (printer.port === "9100") {
    throw new Error("El puerto 9100 requiere un puente local; descarga el archivo ZPL para enviarlo a la impresora.");
  }

  // Other ports are only usable if a local HTTP print bridge exposes POST /print with CORS.
  const ctrl = new AbortController();
  const timeout = setTimeout(() => ctrl.abort(), 5000);
  try {
    const response = await fetch(`http://${printer.ip}:${printer.port}/print`, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: zpl,
      signal: ctrl.signal,
    });
    if (!response.ok) throw new Error(`El puente de impresión devolvió ${response.status}.`);
  } finally {
    clearTimeout(timeout);
  }
}

export function downloadTextFile(filename: string, content: string, mime = "text/plain"): void {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 800);
}
