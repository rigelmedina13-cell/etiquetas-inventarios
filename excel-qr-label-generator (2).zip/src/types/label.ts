export interface MaterialItem {
  id: string;
  codigo: string;
  descripcion: string;
  categoria?: string;
  ubicacion?: string;
  unidad?: string;
  lote?: string;
  /** Any extra columns imported from Excel: key = header name */
  extraFields: Record<string, string>;
}

export interface QueueEntry {
  materialId: string;
  qty: number;
}

export type FontFamilyOption =
  | "roboto"
  | "roboto-condensed"
  | "roboto-mono"
  | "ibm-plex-sans"
  | "arial";

export type TitleScale = "sm" | "md" | "lg" | "xl";
export type BodyScale = "sm" | "md" | "lg";
export type QrSize = "sm" | "md" | "lg";
export type LabelAlignment = "left" | "center" | "right";
export type OutputMode = "browser" | "network";
export type DividerStyle = "solid" | "dashed" | "none";

export interface LabelConfig {
  widthMm: number;
  heightMm: number;
  presetId: string;

  // Contenido — qué columnas del Excel se muestran
  titleField: string; // column key, e.g. "codigo"
  bodyFields: string[]; // column keys in order
  showFieldNames: boolean;
  includeQr: boolean;
  qrField: string; // column key or "__title__"
  qrSize: QrSize;
  qrPosition: "left" | "right";
  bodyAlign: LabelAlignment;
  titleAlign: LabelAlignment;

  // Ajustes libres: se aplican a vista previa e impresión.
  titleFontPt: number | null;
  bodyFontPt: number | null;
  footerFontPt: number | null;
  qrCustomMm: number | null;
  horizontalPaddingMm: number;
  verticalPaddingMm: number;
  footerTrackingEm: number;
  showBorder: boolean;

  // Formato de letra
  fontFamily: FontFamilyOption;
  titleScale: TitleScale;
  bodyScale: BodyScale;
  titleBold: boolean;
  bodyBold: boolean;
  uppercaseAll: boolean;

  // Líneas y pie (clásico)
  dividerStyle: DividerStyle;
  showHeaderDivider: boolean;
  showFooterDivider: boolean;
  footerText: string; // lema inferior

  // Salida e impresora de red
  outputMode: OutputMode;

  // Hoja navegador
  paperMode: "thermal" | "a4" | "letter";
  sheetGapMm: number;
}

export interface NetworkPrinter {
  id: string;
  name: string;
  ip: string;
  port: string;
  dpi: 203 | 300;
}

export interface ColumnMapping {
  codigo: string;
  descripcion: string;
  categoria: string;
  ubicacion: string;
  unidad: string;
  lote: string;
}

export interface LabelSizePreset {
  id: string;
  name: string;
  subtitle: string;
  widthMm: number;
  heightMm: number;
}
