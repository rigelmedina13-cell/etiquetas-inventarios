import React from "react";
import { LabelConfig, MaterialItem } from "../types/label";
import { QrCodeSvg } from "./QrCodeSvg";
import { getColumnLabel, getFieldValue } from "../utils/labelColumns";

interface LabelRendererProps {
  material: MaterialItem;
  config: LabelConfig;
}

export function buildQrPayload(material: MaterialItem, config: LabelConfig): string {
  if (config.qrField === "__title__") {
    return getFieldValue(material, config.titleField) || material.codigo || "SIN-CODIGO";
  }
  const v = getFieldValue(material, config.qrField);
  return v || material.codigo || "SIN-CODIGO";
}

/** Tamaño deseado del QR en mm — misma fórmula para vista previa, navegador y ZPL */
export function getDesiredQrMm(config: LabelConfig, availableTopMm: number): number {
  if (config.qrCustomMm != null) {
    return Math.max(8, Math.min(config.qrCustomMm, availableTopMm, config.widthMm * 0.42, 30));
  }
  const qrSize = (config as Partial<LabelConfig>).qrSize || "md";
  const maxByWidth =
    qrSize === "sm" ? config.widthMm * 0.16 : qrSize === "lg" ? config.widthMm * 0.28 : config.widthMm * 0.21;
  const maxByHeight =
    qrSize === "sm" ? availableTopMm * 0.68 : qrSize === "lg" ? availableTopMm * 1.0 : availableTopMm * 0.88;
  const minMm = qrSize === "sm" ? 8 : 10;
  return Math.max(minMm, Math.min(maxByWidth, maxByHeight, 30));
}

export function getAvailableTopMm(config: LabelConfig, hasBody: boolean, hasFooter: boolean, showHeaderDivider: boolean, showFooterDivider: boolean): number {
  const vPad = config.verticalPaddingMm ?? 1.6;
  const footerBlock = 4.0;
  let reserved = vPad * 2;
  if (hasBody) reserved += config.heightMm * 0.34;
  if (hasFooter) reserved += footerBlock + 0.8;
  if (showHeaderDivider) reserved += 1.6;
  if (showFooterDivider) reserved += 1.6;
  return Math.max(8, config.heightMm - reserved);
}

const FONT_STACKS: Record<LabelConfig["fontFamily"], string> = {
  roboto: "'Roboto', Arial, 'Helvetica Neue', sans-serif",
  "roboto-condensed": "'Roboto Condensed', 'Arial Narrow', Arial, sans-serif",
  "roboto-mono": "'Roboto Mono', 'IBM Plex Mono', ui-monospace, monospace",
  "ibm-plex-sans": "'IBM Plex Sans', system-ui, sans-serif",
  arial: "Arial, 'Helvetica Neue', Helvetica, sans-serif",
};

export const LabelRenderer: React.FC<LabelRendererProps> = ({ material, config }) => {
  const widthRatio = config.widthMm / 100;
  const heightRatio = config.heightMm / 50;
  const scale = Math.max(0.55, Math.min(2.2, Math.min(widthRatio * 0.9 + 0.1, heightRatio)));

  const hPad = config.horizontalPaddingMm ?? 2.4;
  const vPad = config.verticalPaddingMm ?? 1.6;

  const rawTitle = getFieldValue(material, config.titleField);
  const title = (rawTitle || "—").trim() || "—";
  const displayTitle = config.uppercaseAll ? title.toUpperCase() : title;

  const bodyLines = config.bodyFields
    .map((key) => {
      const val = getFieldValue(material, key).trim();
      if (!val) return null;
      const text = config.uppercaseAll ? val.toUpperCase() : val;
      const name = config.showFieldNames ? getColumnLabel(key) : "";
      const displayName = config.uppercaseAll && name ? name.toUpperCase() : name;
      return { key, text, name: displayName };
    })
    .filter((x): x is { key: string; text: string; name: string } => x !== null);

  const hasTitle = Boolean(config.titleField && config.titleField !== "__none__");
  const hasBody = bodyLines.length > 0;
  const hasQr = config.includeQr;
  const hasFooter = Boolean((config.footerText || "").trim());
  const hasTop = hasTitle || hasQr;
  const hasMiddle = hasBody;

  const showHeaderDivider =
    config.showHeaderDivider && config.dividerStyle !== "none" && hasTop && (hasMiddle || hasFooter);
  const showFooterDivider =
    config.showFooterDivider && config.dividerStyle !== "none" && hasFooter && (hasTop || hasMiddle);

  const dividerCss =
    config.dividerStyle === "solid"
      ? "0.28mm solid #111111"
      : config.dividerStyle === "dashed"
      ? "0.28mm dashed #475569"
      : "none";

  const availableTop = getAvailableTopMm(config, hasBody, hasFooter, showHeaderDivider, showFooterDivider);

  const qrSizeMm = getDesiredQrMm(config, availableTop);

  const baseTitlePt =
    config.titleScale === "sm" ? 15 : config.titleScale === "md" ? 19 : config.titleScale === "xl" ? 27 : 23;
  const titlePt = config.titleFontPt ?? Math.max(8, Math.min(42, +(baseTitlePt * scale).toFixed(1)));

  const baseBodyPt = config.bodyScale === "sm" ? 7.6 : config.bodyScale === "lg" ? 10.4 : 8.8;
  const bodyPt = config.bodyFontPt ?? Math.max(6, Math.min(20, +(baseBodyPt * scale).toFixed(1)));

  const footerPt = config.footerFontPt ?? Math.max(5, Math.min(12, +(7.0 * scale).toFixed(1)));
  const footerTracking = config.footerTrackingEm ?? 0.42;

  const fontFamily = FONT_STACKS[config.fontFamily] || FONT_STACKS.roboto;
  const qrPayload = buildQrPayload(material, config);

  return (
    <div
      className="relative bg-white text-black select-none overflow-hidden flex flex-col box-border"
      style={{
        width: `${config.widthMm}mm`,
        height: `${config.heightMm}mm`,
        paddingLeft: `${hPad}mm`,
        paddingRight: `${hPad}mm`,
        paddingTop: `${vPad}mm`,
        paddingBottom: `${vPad}mm`,
        border: config.showBorder ? "0.3mm solid #111" : undefined,
        fontFamily,
      }}
    >
      {hasTop && (
        <div className={`flex items-center shrink-0 ${config.qrPosition === "left" ? "flex-row-reverse" : ""}`} style={{ gap: "2.5mm", justifyContent: "space-between" }}>
          {hasTitle && (
            <div className="flex-1 min-w-0 flex flex-col justify-center" style={{ alignItems: config.titleAlign === "left" ? "flex-start" : config.titleAlign === "right" ? "flex-end" : "center", textAlign: config.titleAlign || "center" }}>
              <div
                className="leading-[1.05] break-all"
                style={{
                  fontSize: `${titlePt}pt`,
                  fontWeight: config.titleBold ? 800 : 500,
                  letterSpacing: "-0.02em",
                  lineHeight: 1.05,
                }}
              >
                {displayTitle}
              </div>
            </div>
          )}
          {hasQr && (
            <div className={`shrink-0 flex flex-col items-center justify-center ${!hasTitle ? "mx-auto" : ""}`}>
              <QrCodeSvg
                value={qrPayload}
                errorCorrectionLevel="M"
                fgColor="#000000"
                bgColor="#FFFFFF"
                style={{ width: `${qrSizeMm}mm`, height: `${qrSizeMm}mm`, display: "block" }}
              />
            </div>
          )}
        </div>
      )}

      {showHeaderDivider && (
        <div
          className="shrink-0"
          style={{
            borderTop: dividerCss,
            marginLeft: `-${hPad}mm`,
            marginRight: `-${hPad}mm`,
            marginTop: "1.1mm",
          }}
        />
      )}

      {hasMiddle && (
        <div className="flex-1 min-h-0 flex flex-col justify-center" style={{ padding: "1mm 0" }}>
          <div style={{ textAlign: config.bodyAlign || "center" }}>
            {bodyLines.map((line) => (
              <div
                key={line.key}
                className="break-words"
                style={{ fontSize: `${bodyPt}pt`, fontWeight: config.bodyBold ? 700 : 500, lineHeight: 1.25 }}
              >
                {config.showFieldNames && line.name ? (
                  <>
                    <span style={{ opacity: 0.62, fontWeight: 600 }}>{line.name}: </span>
                    <span>{line.text}</span>
                  </>
                ) : (
                  line.text
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {showFooterDivider && (
        <div
          className="shrink-0 mt-auto"
          style={{
            borderTop: dividerCss,
            marginLeft: `-${hPad}mm`,
            marginRight: `-${hPad}mm`,
            marginBottom: "1mm",
          }}
        />
      )}

      {hasFooter && (
        <div className={`shrink-0 w-full ${!showFooterDivider ? "mt-auto" : ""}`} style={{ textAlign: "center" }}>
          <div
            className="uppercase whitespace-nowrap overflow-hidden"
            style={{
              fontSize: `${footerPt}pt`,
              fontWeight: 500,
              letterSpacing: `${footerTracking}em`,
              transform: `translateX(${footerTracking / 2}em)`,
              fontFamily: "'Roboto', Arial, sans-serif",
            }}
          >
            {(config.uppercaseAll ? config.footerText.toUpperCase() : config.footerText.toUpperCase()).slice(0, 40)}
          </div>
        </div>
      )}

      {!hasTop && !hasMiddle && !hasFooter && (
        <div className="m-auto text-center text-[8pt] text-neutral-400">Sin contenido para mostrar</div>
      )}
    </div>
  );
};
