import { useState } from "react";
import { Check, FileSpreadsheet, X } from "lucide-react";
import { ColumnMapping } from "../types/label";
import { extractSheetData, ParsedWorkbookData } from "../utils/excelHelper";

type MappedField = keyof ColumnMapping;

const mappingFields: { key: MappedField; label: string }[] = [
  { key: "codigo", label: "Número del material *" },
  { key: "descripcion", label: "Descripción *" },
  { key: "ubicacion", label: "Ubicación" },
  { key: "unidad", label: "Unidad" },
  { key: "categoria", label: "Categoría" },
  { key: "lote", label: "Lote / serie" },
];

function initialSelection(parsed: ParsedWorkbookData): string[] {
  return [parsed.mapping.codigo, parsed.mapping.descripcion].filter(Boolean);
}

interface Props {
  parsed: ParsedWorkbookData;
  saving: boolean;
  onClose: () => void;
  onSave: (session: ParsedWorkbookData, selectedHeaders: string[]) => Promise<void>;
}

export function ExcelImportDialog({ parsed, saving, onClose, onSave }: Props) {
  const [session, setSession] = useState(parsed);
  const [selectedHeaders, setSelectedHeaders] = useState<string[]>(() => initialSelection(parsed));
  const [error, setError] = useState("");

  const changeSheet = (sheetName: string) => {
    const sheet = extractSheetData(session.workbook, sheetName);
    const next = { ...session, activeSheet: sheetName, ...sheet };
    setSession(next);
    setSelectedHeaders(initialSelection(next));
    setError("");
  };

  const changeMapping = (key: MappedField, header: string) => {
    setSession((previous) => ({
      ...previous,
      mapping: { ...previous.mapping, [key]: header },
    }));
    setError("");
  };

  const toggleHeader = (header: string) => {
    setSelectedHeaders((previous) =>
      previous.includes(header)
        ? previous.filter((value) => value !== header)
        : [...previous, header]
    );
    setError("");
  };

  const submit = async () => {
    const { codigo, descripcion } = session.mapping;
    if (!codigo || !descripcion || codigo === descripcion) {
      setError("Selecciona columnas diferentes para el número y la descripción.");
      return;
    }
    if (selectedHeaders.length === 0) {
      setError("Selecciona al menos una columna para mostrar en el catálogo.");
      return;
    }
    if (session.rawRows.length === 0) {
      setError("Esta hoja no contiene materiales. Selecciona otra hoja.");
      return;
    }
    await onSave(session, selectedHeaders);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-6" onMouseDown={(event) => {
      if (event.target === event.currentTarget && !saving) onClose();
    }}>
      <div role="dialog" aria-modal="true" aria-labelledby="import-title" className="flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-xl border bg-white shadow-2xl" style={{ borderColor: "var(--border)" }}>
        <div className="flex items-start justify-between gap-4 border-b px-5 py-4" style={{ borderColor: "var(--border)" }}>
          <div>
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="size-5 text-orange-600" />
              <h2 id="import-title" className="font-display text-xl font-bold">Preparar importación de Excel</h2>
            </div>
            <p className="mt-1 text-sm" style={{ color: "var(--muted-foreground)" }}>
              {session.fileName} · Elige las columnas antes de guardar en la base de datos local.
            </p>
          </div>
          <button type="button" onClick={onClose} disabled={saving} className="rounded-md p-2 hover:bg-neutral-100 disabled:opacity-40" aria-label="Cancelar importación"><X className="size-5" /></button>
        </div>

        <div className="nice-scroll space-y-6 overflow-y-auto px-5 py-5">
          {session.sheetNames.length > 1 && (
            <div className="grid gap-2">
              <label htmlFor="excel-sheet" className="text-sm font-semibold">Hoja del archivo</label>
              <select id="excel-sheet" value={session.activeSheet} onChange={(event) => changeSheet(event.target.value)} className="h-10 rounded-md border bg-white px-3 text-sm" style={{ borderColor: "var(--input)" }}>
                {session.sheetNames.map((sheet) => <option key={sheet} value={sheet}>{sheet}</option>)}
              </select>
            </div>
          )}

          <section>
            <h3 className="font-display text-lg font-bold">1. Identifica las columnas</h3>
            <p className="mb-3 text-sm" style={{ color: "var(--muted-foreground)" }}>Comprueba qué columna del archivo corresponde a cada dato. Las otras columnas se conservan como campos adicionales.</p>
            <div className="grid gap-3 sm:grid-cols-2">
              {mappingFields.map(({ key, label }) => (
                <label key={key} className="grid gap-1.5 text-sm font-medium">
                  {label}
                  <select value={session.mapping[key]} onChange={(event) => changeMapping(key, event.target.value)} className="h-10 min-w-0 rounded-md border bg-white px-2 text-sm" style={{ borderColor: "var(--input)" }}>
                    <option value="">{key === "codigo" || key === "descripcion" ? "Selecciona una columna" : "No usar"}</option>
                    {session.headers.map((header) => <option key={header} value={header}>{header}</option>)}
                  </select>
                </label>
              ))}
            </div>
          </section>

          <section>
            <h3 className="font-display text-lg font-bold">2. Columnas visibles en el catálogo</h3>
            <p className="mb-3 text-sm" style={{ color: "var(--muted-foreground)" }}>Los demás datos se conservan. Puedes cambiar la selección más tarde desde el catálogo.</p>
            <div className="grid gap-x-4 gap-y-1 sm:grid-cols-2">
              {session.headers.map((header) => (
                <label key={header} className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-2 text-sm hover:bg-neutral-50">
                  <input type="checkbox" checked={selectedHeaders.includes(header)} onChange={() => toggleHeader(header)} className="size-4 accent-[var(--primary)]" />
                  <span className="truncate" title={header}>{header}</span>
                </label>
              ))}
            </div>
          </section>

          <section>
            <h3 className="font-display text-lg font-bold">3. Vista previa de los datos</h3>
            <p className="mb-3 text-sm" style={{ color: "var(--muted-foreground)" }}>{session.rawRows.length} filas encontradas · primeras 4 filas</p>
            <div className="nice-scroll overflow-x-auto rounded-md border" style={{ borderColor: "var(--border)" }}>
              <table className="min-w-full border-collapse text-left text-xs">
                <thead className="bg-neutral-100"><tr>{session.headers.map((header) => <th key={header} className="whitespace-nowrap border-b px-3 py-2 font-semibold">{header}</th>)}</tr></thead>
                <tbody>{session.rawRows.slice(0, 4).map((row, index) => (
                  <tr key={index} className="border-t">{session.headers.map((header) => <td key={header} className="max-w-56 truncate px-3 py-2" title={String(row[header] ?? "")}>{String(row[header] ?? "")}</td>)}</tr>
                ))}</tbody>
              </table>
            </div>
          </section>
          {error && <p role="alert" className="text-sm font-medium text-red-700">{error}</p>}
        </div>

        <div className="flex items-center justify-between gap-3 border-t px-5 py-4" style={{ borderColor: "var(--border)" }}>
          <p className="text-xs" style={{ color: "var(--muted-foreground)" }}>{selectedHeaders.length} columnas visibles</p>
          <div className="flex gap-2">
            <button type="button" onClick={onClose} disabled={saving} className="rounded-md border px-4 py-2 text-sm font-medium hover:bg-neutral-50 disabled:opacity-40" style={{ borderColor: "var(--border)" }}>Cancelar</button>
            <button type="button" onClick={submit} disabled={saving || session.rawRows.length === 0} className="inline-flex items-center gap-2 rounded-md px-4 py-2 text-sm font-semibold disabled:opacity-40" style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}><Check className="size-4" />{saving ? "Guardando..." : "Guardar materiales"}</button>
          </div>
        </div>
      </div>
    </div>
  );
}