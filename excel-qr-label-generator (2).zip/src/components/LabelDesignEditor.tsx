import { RotateCcw } from "lucide-react";
import { DEFAULT_LABEL_CONFIG } from "../data/defaultMaterials";
import { LabelConfig } from "../types/label";

interface Props {
  config: LabelConfig;
  onChange: (patch: Partial<LabelConfig>) => void;
}

function DesignSlider({ label, value, min, max, step = 1, unit, onChange }: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit: string;
  onChange: (value: number) => void;
}) {
  return (
    <label className="grid gap-1.5 text-sm">
      <span className="flex items-center justify-between gap-2">
        <span>{label}</span>
        <span className="font-mono text-xs" style={{ color: "var(--muted-foreground)" }}>{value} {unit}</span>
      </span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} className="w-full accent-orange-500" />
    </label>
  );
}

export function LabelDesignEditor({ config, onChange }: Props) {
  const reset = () => onChange({
    titleFontPt: null,
    bodyFontPt: null,
    footerFontPt: null,
    qrCustomMm: null,
    horizontalPaddingMm: DEFAULT_LABEL_CONFIG.horizontalPaddingMm,
    verticalPaddingMm: DEFAULT_LABEL_CONFIG.verticalPaddingMm,
    footerTrackingEm: DEFAULT_LABEL_CONFIG.footerTrackingEm,
    showBorder: false,
    titleAlign: "center",
  });

  return (
    <details className="border-t pt-4" style={{ borderColor: "var(--border)" }}>
      <summary className="cursor-pointer font-display text-lg font-bold">Modificar diseño a voluntad</summary>
      <div className="grid gap-4 pt-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>Ajusta las medidas y observa el cambio en tiempo real.</p>
        </div>
        <button type="button" onClick={reset} className="inline-flex shrink-0 items-center gap-1 rounded-md border px-2 py-1 text-xs hover:bg-neutral-50" style={{ borderColor: "var(--border)" }}><RotateCcw className="size-3" /> Restablecer</button>
      </div>

      <label className="grid gap-1.5 text-sm">
        Alineación del título
        <select value={config.titleAlign || "center"} onChange={(event) => onChange({ titleAlign: event.target.value as LabelConfig["titleAlign"] })} className="h-10 rounded-md border bg-white px-3" style={{ borderColor: "var(--input)" }}>
          <option value="left">Izquierda</option><option value="center">Centrado</option><option value="right">Derecha</option>
        </select>
      </label>

      <div className="grid gap-4">
        <DesignSlider label="Tamaño del título" min={8} max={38} unit="pt" value={config.titleFontPt ?? 27} onChange={(value) => onChange({ titleFontPt: value })} />
        <DesignSlider label="Tamaño del cuerpo" min={6} max={18} unit="pt" value={config.bodyFontPt ?? 9} onChange={(value) => onChange({ bodyFontPt: value })} />
        <DesignSlider label="Tamaño del lema" min={5} max={13} unit="pt" value={config.footerFontPt ?? 7} onChange={(value) => onChange({ footerFontPt: value })} />
        {config.includeQr && <DesignSlider label="Tamaño del QR" min={8} max={30} unit="mm" value={config.qrCustomMm ?? 19} onChange={(value) => onChange({ qrCustomMm: value })} />}
        <div className="grid grid-cols-2 gap-4">
          <DesignSlider label="Margen lateral" min={1} max={8} step={0.5} unit="mm" value={config.horizontalPaddingMm ?? 2.4} onChange={(value) => onChange({ horizontalPaddingMm: value })} />
          <DesignSlider label="Margen vertical" min={0.5} max={6} step={0.5} unit="mm" value={config.verticalPaddingMm ?? 1.6} onChange={(value) => onChange({ verticalPaddingMm: value })} />
        </div>
        <DesignSlider label="Espaciado del lema" min={0} max={0.8} step={0.05} unit="em" value={config.footerTrackingEm ?? 0.42} onChange={(value) => onChange({ footerTrackingEm: value })} />
      </div>

      <label className="flex cursor-pointer items-center justify-between gap-3 text-sm">
        Mostrar borde exterior
        <input type="checkbox" checked={config.showBorder ?? false} onChange={(event) => onChange({ showBorder: event.target.checked })} className="size-4 accent-[var(--primary)]" />
      </label>
      </div>
    </details>
  );
}