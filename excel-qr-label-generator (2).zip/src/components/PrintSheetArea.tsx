import React from "react";
import { LabelConfig, MaterialItem } from "../types/label";
import { LabelRenderer } from "./LabelRenderer";

interface PrintSheetAreaProps {
  labelsToPrint: MaterialItem[];
  config: LabelConfig;
}

export const PrintSheetArea: React.FC<PrintSheetAreaProps> = ({ labelsToPrint, config }) => {
  const isThermal = config.paperMode === "thermal";

  const pageCss = isThermal
    ? `@page { size: ${config.widthMm}mm ${config.heightMm}mm; margin: 0mm; }`
    : `@page { size: ${config.paperMode === "a4" ? "A4" : "letter"} portrait; margin: 8mm; }`;

  return (
    <div id="print-area" className="hidden print:block bg-white">
      <style>{pageCss}</style>
      {isThermal ? (
        <div>
          {labelsToPrint.map((item, index) => {
            const isLast = index === labelsToPrint.length - 1;
            return (
              <div
                key={`p-${item.id}-${index}`}
                style={{
                  width: `${config.widthMm}mm`,
                  height: `${config.heightMm}mm`,
                  overflow: "hidden",
                  pageBreakAfter: isLast ? "auto" : "always",
                  breakAfter: isLast ? "auto" : "page",
                }}
              >
                <LabelRenderer material={item} config={config} />
              </div>
            );
          })}
        </div>
      ) : (
        <div className="flex flex-wrap items-start content-start" style={{ gap: `${config.sheetGapMm}mm` }}>
          {labelsToPrint.map((item, index) => (
            <div
              key={`p-${item.id}-${index}`}
              style={{
                width: `${config.widthMm}mm`,
                height: `${config.heightMm}mm`,
                breakInside: "avoid",
                pageBreakInside: "avoid",
              }}
            >
              <LabelRenderer material={item} config={config} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
