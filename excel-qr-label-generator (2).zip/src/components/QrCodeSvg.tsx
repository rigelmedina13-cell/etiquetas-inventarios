import React, { useMemo } from "react";
import QRCode, { QRCodeErrorCorrectionLevel } from "qrcode";

interface QrCodeSvgProps {
  value: string;
  errorCorrectionLevel?: QRCodeErrorCorrectionLevel;
  className?: string;
  style?: React.CSSProperties;
  fgColor?: string;
  bgColor?: string;
}

export function generateQrPathData(
  text: string,
  errorCorrectionLevel: QRCodeErrorCorrectionLevel = "M"
): { size: number; path: string } {
  const safeValue = text.trim() ? text : "SIN-CODIGO";
  try {
    const qr = QRCode.create(safeValue, {
      errorCorrectionLevel,
    });
    const modules = qr.modules;
    const size = modules.size;
    let path = "";

    for (let r = 0; r < size; r++) {
      let runStart = -1;
      for (let c = 0; c < size; c++) {
        const isDark = modules.get(r, c) === 1;
        if (isDark && runStart === -1) {
          runStart = c;
        } else if (!isDark && runStart !== -1) {
          path += `M${runStart} ${r}h${c - runStart}v1h-${c - runStart}z`;
          runStart = -1;
        }
      }
      if (runStart !== -1) {
        path += `M${runStart} ${r}h${size - runStart}v1h-${size - runStart}z`;
      }
    }

    return { size, path };
  } catch {
    return { size: 21, path: "" };
  }
}

export const QrCodeSvg: React.FC<QrCodeSvgProps> = ({
  value,
  errorCorrectionLevel = "M",
  className = "",
  style,
  fgColor = "#000000",
  bgColor = "#FFFFFF",
}) => {
  const { size, path } = useMemo(
    () => generateQrPathData(value, errorCorrectionLevel),
    [value, errorCorrectionLevel]
  );

  // Add a 1-module quiet zone around the QR matrix
  const viewBoxSize = size + 2;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox={`0 0 ${viewBoxSize} ${viewBoxSize}`}
      shapeRendering="crispEdges"
      className={className}
      style={style}
      aria-label={`Código QR: ${value}`}
    >
      <rect x={0} y={0} width={viewBoxSize} height={viewBoxSize} fill={bgColor} />
      <g transform="translate(1, 1)">
        <path d={path} fill={fgColor} />
      </g>
    </svg>
  );
};
