# Publicar sin Netlify

La app es estática. Compílala con `npm run build`: el sitio listo para publicar queda en `dist/`.

## Cloudflare Pages (URL gratuita, sin Netlify)

1. Entra en https://dash.cloudflare.com/ y crea o inicia sesión en una cuenta.
2. Abre **Workers & Pages** > **Create** > **Pages** > **Upload assets**.
3. Elige un nombre para el proyecto y sube la carpeta `dist/`.
4. Cloudflare asigna una URL `https://NOMBRE.pages.dev` si ese nombre está disponible.
5. Para una URL con dominio propio, registra un dominio y conéctalo en **Custom domains** del proyecto.

No es posible reservar el nombre ni publicar un dominio desde este proyecto sin acceso a la cuenta que administrará el sitio y, para dominios propios, sin controlar el DNS del dominio.

El catálogo Excel se guarda en IndexedDB de **cada navegador y cada origen**. Si ya importaste datos en `localhost`, usa **... > Descargar respaldo del catálogo** e impórtalo en la URL publicada. Para sincronizar materiales entre equipos distintos hace falta agregar un servidor y una base de datos compartida.